***Last Updated: 1/24/2017 Stata14
/*==========================================*
Paper:			For Better or for Worse: Education and the Prevalence of Domestic Violence in Turkey

Purpose:        Data cleaning for the household dataset from Turkish National Survey on Domestic Violence against Women (TNSDVW)

To re-run our analysis, please install a folder "Domestic Violence". There should be 5 subfolders in order for do-files to run:

"originals"
"created"
"do files"
"graphs"
"output"

To run the do file all you need to do is to change the path of the working directory in line 34.

The dataset used in this do file is provided by the Turkish Statistical Institute (TSI). Their data availability policy 
prohibits the distribution of data to non-registered users. Researchers have to complete a form 
(http://www.turkstat.gov.tr/UstMenu/body/bilgitalep/MVKullaniciTalepFormu_ENG.pdf), and send it 
to bilgi@tuik.gov.tr by e-mail. Upon receipt of this form, the TSI sends 
the datasets through an ftp server electronically. 

The name of the dataset sent by the TSI will be as follows: TKAA2008HANEDATA????????.sav. Please convert this data in spss
format into Stata format, and save it as "Domestic Violence/originals/household_from_spss.dta" before you run this
do file.

*==========================================*/
clear
set more off 
set matsize 8000
cap log close
#delimit ;

global dir="XXX\Domestic Violence";
cd "$dir";

use "originals\household_from_spss.dta", clear;

*Create unique household ID;
gen HHID = qhclust*1000+qhnumber;
sort HHID;
order HHID;

**Create asset index;
g cellphone=.;
replace cellphone=0 if qh23p==0;
replace cellphone=1 if qh23p>0;
replace cellphone=. if qh23p==.;
g car=.;
replace car=0 if qh23v==0;
replace car=1 if qh23v>0;
replace car=. if qh23v==.;

foreach var in 
qh23a qh23b qh23c qh23d qh23e qh23f qh23g qh23h qh23i qh23j qh23k qh23l qh23m qh23n qh23o qh23r qh23s qh23t qh23u qh23y qh23z qh23z1 cellphone car{;
egen z_`var'=std(`var');
};
egen z_asset=rowmean(z_qh23a z_qh23b z_qh23c z_qh23d z_qh23e z_qh23f z_qh23g z_qh23h z_qh23i z_qh23j z_qh23k z_qh23l z_qh23m z_qh23n z_qh23o z_qh23r z_qh23s z_qh23t z_qh23u z_qh23y z_qh23z z_qh23z1 z_cellphone z_car);
drop z_qh23a z_qh23b z_qh23c z_qh23d z_qh23e z_qh23f z_qh23g z_qh23h z_qh23i z_qh23j z_qh23k z_qh23l z_qh23m z_qh23n z_qh23o z_qh23r z_qh23s z_qh23t z_qh23u z_qh23y z_qh23z z_qh23z1 z_cellphone z_car;
label variable z_asset "z-score: all asset variables";

drop qh* cellphone car;

sort HHID;
order HHID;

save "created/household_data_for_analysis.dta", replace;
