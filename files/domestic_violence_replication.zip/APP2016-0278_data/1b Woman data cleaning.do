***Last Updated: 1/24/2017 Stata14
/*==========================================*
Paper:			For Better or for Worse: Education and the Prevalence of Domestic Violence in Turkey

Purpose:        Data cleaning for the main dataset from Turkish National Survey on Domestic Violence against Women (TNSDVW)

To re-run our analysis, please install a folder "Domestic Violence". There should be 5 subfolders in order for do-files to run:

"originals"
"created"
"do files"
"graphs"
"output"

To run the do file all you need to do is to change the path of the working directory in line 34.

The dataset used in this do file is provided by the Turkish Statistical Institute (TSI). Their data availability policy 
prohibits the distribution of data to non-registered users. Researchers have to complete a form 
(http://www.turkstat.gov.tr/UstMenu/body/bilgitalep/MVKullaniciTalepFormu_ENG.pdf), and send it 
to bilgi@tuik.gov.tr by e-mail. Upon receipt of this form, the TSI sends 
the datasets through an ftp server electronically. 

The name of the dataset sent by the TSI will be as follows: TKAA2008KADINDATA????????.sav. Please convert this data in spss
format into Stata format, and save it as "Domestic Violence/originals/women_from_spss.dta" before you run this
do file.

*==========================================*/
clear
set more off 
set matsize 8000
cap log close
#delimit ;

global dir="XXX\Domestic Violence";
cd "$dir";

use "originals/women_from_spss.dta", clear;

*Create unique household ID;
gen HHID = qcluster*1000+qnumber;
sort HHID;
order HHID;

label variable HHID "Unique household ID";

*SCHOOLING VARIABLE;
gen schooling = .;
replace schooling=. if q105a == 98|q105b == 98;
replace q105b = 0 if q105b == 66;
*Take care of coding errors;
replace q105a = 13 if q105a==11&q105b>5;
replace q105a = 13 if q105a==12&q105b>3;
replace q105b=4 if q105a==15&q105b>4;
replace schooling=. if q105a == 14&q105b>4;
replace schooling=. if q105a == 11&q105b==0&q105c==1;

replace schooling = q105b if q105a==11;
replace schooling = 5+q105b if q105a==12;
replace schooling = q105b if q105a==13;
replace schooling = 8+q105b if q105a==14;
replace schooling = 11+q105b if q105a==15;
replace schooling = 15+q105b if q105a==16;

label variable schooling "Years of schooling";

gen jhighschool = 0;
replace jhighschool = 1 if q105a==12 & q105c==1;
replace jhighschool = 1 if q105a==13 & q105c==1;
replace jhighschool = 1 if q105a==14 | q105a==15 | q105a==16;
replace jhighschool =. if q105a==98;
replace jhighschool =. if q105a==.;

gen highschool = 0;
replace highschool = 1 if q105a==14 & q105c==1;
replace highschool = 1 if q105a==15 | q105a==16;
replace highschool =. if q105a==98;
replace highschool =. if q105a==.;

gen primaryschool = 0;
replace primaryschool = 1 if q105a==11 & q105c==1;
replace primaryschool = 1 if q105a== 12 | q105a==13 | q105a==14 | q105a==15 | q105a==16;
replace primaryschool =. if q105a==98;
replace primaryschool =. if q105a==.;

label variable jhighschool "Dummy:1 if last degree is junior high";
label variable highschool "Dummy:1 if last degree is high school";
label variable primaryschool "Dummy:1 if last degree is primary school";

*PARTNER'S SCHOOLING, RELIGIOSITY, AND REASONS FOR PHYSICAL VIOLENCE;
gen schooling_partner = .;
replace schooling_partner = . if q402b == .|q402b == 98|q402c == 98;
replace q402c = 0 if q402c == 66;
*Take care of coding errors;
replace q402b = 13 if q402b==11&q402c>5;
replace q402b = 13 if q402b==12&q402c>3;
replace q402c=4 if q402b==15&q402c>4;
replace schooling_partner=. if q402b == 14&q402c>4;
replace schooling_partner=. if q402b == 11&q402c==0&q402d==1;
replace schooling_partner = q402c if q402b==11;
replace schooling_partner = 5+q402c if q402b==12;
replace schooling_partner = q402c if q402b==13;
replace schooling_partner = 8+q402c if q402b==14;
replace schooling_partner = 11+q402c if q402b==15;
replace schooling_partner = 15+q402c if q402b==16;
replace schooling_partner = . if schooling_partner ==.a;
replace schooling_partner = . if schooling_partner ==98 | schooling_partner ==106;

label variable schooling_partner "Partner's years of schooling"; 

gen schooling_gap=schooling_partner-schooling;
label variable schooling_gap "Gap between male and female schooling within couples";

gen jhighschool_partner = 0;
replace jhighschool_partner = 1 if q402b==12 & q402d==1;
replace jhighschool_partner = 1 if q402b==13 & q402d==1;
replace jhighschool_partner = 1 if q402b==14 |q402b==15| q402b==16 ;
replace jhighschool_partner =. if q402b==98;

label variable jhighschool_partner "Dummy:1 if last degree partner earned is junior high";

gen notdrinking=.;
replace notdrinking=1 if q405==0;
replace notdrinking=0 if q405==1|q405==2|q405==3|q405==4;
replace notdrinking=. if q405==8|q405==9;

label variable notdrinking "Dummy:1 if husband does not consume alcoholic beverages";

gen notgambling=.;
replace notgambling=1 if q407==0;
replace notgambling=0 if q407==1|q407==2|q407==3|q407==4|q407==5;
replace notgambling=. if q407==8|q407==9;

label variable notgambling "Dummy:1 if husband does not gamble";

gen nodrugs=.;
replace nodrugs=1 if q408==0;
replace nodrugs=0 if q408==1|q408==2|q408==3|q408==4;
replace nodrugs=. if q408==8|q408==9;

label variable nodrugs "Dummy:1 if husband does not use any narcotic drugs";

gen affair=.;
replace affair=1 if q409==1 | q409==3 ;
replace affair=0 if q409==2;
replace affair=. if q408==8|q408==9;

label variable affair "Dummy:1 if husband has an affair";

gen noaffair=.;
replace noaffair=1 if affair==0;
replace noaffair=0 if affair==1;

label variable noaffair "Dummy:1 if husband did not have an affair";

drop affair;

foreach var in 
notdrinking notgambling nodrugs noaffair{;
egen z_`var'=std(`var');
};
egen z_malereligious=rowmean(z_notdrinking z_notgambling z_nodrugs z_noaffair);
drop z_notdrinking z_notgambling z_nodrugs z_noaffair;

label variable z_malereligious "Z-score proxy for the religiosity of the male partner";

gen partner_reason_jealous=q701j;
label variable partner_reason_jealous "Dummy:1 if partner's reason for physical violence is that he is jealous of the woman";

gen partner_reason_economic=.;
replace partner_reason_economic=0 if q701c==0|q701d==0|q701e==0|q701f==0;
replace partner_reason_economic=1 if q701c==1|q701d==1|q701e==1|q701f==1;
label variable partner_reason_economic "Dummy:1 if partner's reason for physical violence is economic";

gen partner_reason_pfamily=q701h;
label variable partner_reason_pfamily "Dummy:1 if partner's reason for physical violence is problems with partner's family";

gen partner_reason_wfamily=q701g;
label variable partner_reason_wfamily "Dummy:1 if partner's reason for physical violence is problems with woman's family";

gen partner_reason_fidelity=q701k;
label variable partner_reason_fidelity "Dummy:1 if partner's reason for physical violence is that he is suspicious of her fidelity";

gen partner_reason_sex=q701l;
label variable partner_reason_sex "Dummy:1 if partner's reason for physical violence is that she refuses sex";

gen partner_reason_disobey=q701m;
label variable partner_reason_disobey "Dummy:1 if partner's reason for physical violence is that she disobeys him";

gen partner_reason_wjealous=q701n;
label variable partner_reason_wjealous "Dummy:1 if partner's reason for physical violence is that woman is jealous of her partner";

gen partner_reason_children=q701o;
label variable partner_reason_children "Dummy:1 if partner's reason for physical violence is problems with children";

*AGE VARIABLE AND DIFFERENCES;
drop if q101m==.a;
drop if q101m==98;
rename q101m month;
drop if q101y==9998;
rename q101y year;

label variable month "Month of birth";
label variable year "Year of birth";

gen dif=.;
replace dif = (-1)*[(12*(1987-year-1))+(12-month)+1] if year<1987;
replace dif = [(12*(year-1987-1))+month+11] if year>1987;
replace dif = (-1)*[1-month] if year==1987&month<1;
replace dif = month - 1 if year==1987&month>=1;

label variable dif "Born after January 1987 (in months)";

gen di1=dif;
gen di1_i=dif;
replace di1_i=0 if dif<0;
gen di2=dif^2;
gen di2_i=dif^2;
replace di2_i=0 if dif<0;
gen di3=dif^3;
gen di3_i=dif^3;
replace di3_i=0 if dif<0;

gen after1986=0;
replace after1986=1 if dif>=0;

label variable after1986 "Dummy:1 if born after January 1987";

gen modate = ym(year, month);
format modate %tm;

label variable modate "Birth month and year variables";

*GENERATE OTHER IMPORTANT CONTROL VARIABLES;
*Month of birth;
tab month, gen(month_);

foreach num of numlist 1(1)12{;
label variable month_`num' "Birth month dummies";
};

*Relationship (ever married or ever engaged/have boyfriend);
gen rel=.;
replace rel=1 if q113==1 | q116==1;
replace rel=0 if q119 == 11;

label variable rel "Dummy:1 if ever married or in a relationship";

*Ever married;
gen married=.;
replace married=1 if q113==1;
replace married=0 if q113 == 2;

label variable married "Dummy:1 if ever married";

*Language;
gen noturkish=.;
replace noturkish=1 if q907==2 | q907==3 | q907== 7;
replace noturkish=0 if q907==1;

label variable noturkish "Dummy:1 if not a Turkish speaker";

*Urban vs. Rural;
gen rural=0;
replace rural=1 if qtyper==2;

label variable rural "Dummy:1 if living in a village now";

*Region of childhood;
gen rural_pre12=.;
replace rural_pre12=1 if q102a==0&rural==1;
replace rural_pre12=0 if q102a==0&rural==0;
replace rural_pre12=1 if q102a==3 | q102a==2;
replace rural_pre12=0 if q102a==1;

label variable rural_pre12 "Dummy:1 if childhood region (before age 12) is rural";

gen province_pre12=q102b;

label variable province_pre12 "Province they lived in before age 12";

*12 regions of childhood;
gen region_pre12=.;
replace region_pre12=1 if province_pre12==34;
replace region_pre12=2 if province_pre12==10 |province_pre12==17 |province_pre12==22 |province_pre12==39 |province_pre12==59;
replace region_pre12=3 if province_pre12==20 |province_pre12==35 |province_pre12==43 |province_pre12==45 |province_pre12==48| province_pre12==3 |province_pre12==9 |province_pre12==64;
replace region_pre12=4 if province_pre12==14 |province_pre12==16 |province_pre12==26 |province_pre12==41 |province_pre12==81| province_pre12==81 |province_pre12==11|province_pre12==54|province_pre12==77;
replace region_pre12=5 if province_pre12==6 |province_pre12==42 |province_pre12==70 ;
replace region_pre12=6 if province_pre12==1 |province_pre12==7 |province_pre12==15|province_pre12==31 |province_pre12==32|province_pre12==33 |province_pre12==46|province_pre12==80;
replace region_pre12=7 if province_pre12==38 |province_pre12==40 |province_pre12==51 |province_pre12==66 |province_pre12==71|province_pre12==68 |province_pre12==50|province_pre12==58;
replace region_pre12=8 if province_pre12==19 |province_pre12==37 |province_pre12==55 |province_pre12==60 |province_pre12==67|province_pre12==78|province_pre12==74|province_pre12==18|province_pre12==57|province_pre12==5;
replace region_pre12=9 if province_pre12==61 |province_pre12==52 |province_pre12==28 |province_pre12==53|province_pre12==8|province_pre12==29;
replace region_pre12=10 if province_pre12==4 |province_pre12==24 |province_pre12==25 |province_pre12==36 |province_pre12==76|province_pre12==69|province_pre12==75;
replace region_pre12=11 if province_pre12==12 |province_pre12==23 |province_pre12==44 |province_pre12==65|province_pre12==62|province_pre12==30|province_pre12==49|province_pre12==13;
replace region_pre12=12 if province_pre12==21 |province_pre12==27 |province_pre12==47 |province_pre12==63 |province_pre12==73|province_pre12==2|province_pre12==79|province_pre12==72|province_pre12==56;

label variable region_pre12 "12 Regions they lived in before age 12";

tab region_pre12, gen(region_pre12_);

*5 regions of childhood;
gen region5_pre12=.;
replace region5_pre12=1 if region_pre12==1|region_pre12==2|region_pre12==3|region_pre12==4;
replace region5_pre12=2 if region_pre12==6;
replace region5_pre12=3 if region_pre12==5| region_pre12==7;
replace region5_pre12=4 if region_pre12==8| region_pre12==9;
replace region5_pre12=5 if region_pre12==10| region_pre12==11| region_pre12==12;

tab region5_pre12, gen(region5_pre12_);

label variable region5_pre12 "5 Regions they lived in before age 12";

*26 regions of childhood;
gen region26_pre12=.;
replace region26_pre12=1 if province_pre12==34;
replace region26_pre12=2 if province_pre12==22 | province_pre12==39 | province_pre12==59;
replace region26_pre12=3 if province_pre12==10 |province_pre12==17;
replace region26_pre12=4 if province_pre12==35;
replace region26_pre12=5 if province_pre12==9| province_pre12==20|province_pre12==48;
replace region26_pre12=6 if province_pre12==45 |province_pre12==3 |province_pre12==43 |province_pre12==64;
replace region26_pre12=7 if province_pre12==16 |province_pre12==26 |province_pre12==11;
replace region26_pre12=8 if province_pre12==41 |province_pre12==54 |province_pre12==81 |province_pre12==14|province_pre12==77;
replace region26_pre12=9 if province_pre12==6 ;
replace region26_pre12=10 if province_pre12==42 |province_pre12==70 ;
replace region26_pre12=11 if province_pre12==7 |province_pre12==32 |province_pre12==15;
replace region26_pre12=12 if province_pre12==1 |province_pre12==33;
replace region26_pre12=13 if province_pre12==31 |province_pre12==46 |province_pre12==80;
replace region26_pre12=14 if province_pre12==71 |province_pre12==68 |province_pre12==51|province_pre12==50|province_pre12==40;
replace region26_pre12=15 if province_pre12==38 |province_pre12==58 |province_pre12==66;
replace region26_pre12=16 if province_pre12==67 |province_pre12==78 |province_pre12==74;
replace region26_pre12=17 if province_pre12==37 |province_pre12==18 |province_pre12==57;
replace region26_pre12=18 if province_pre12==55 |province_pre12==60 |province_pre12==19 |province_pre12==5;
replace region26_pre12=19 if province_pre12==61 |province_pre12==52 |province_pre12==28 |province_pre12==53|province_pre12==8|province_pre12==29;
replace region26_pre12=20 if province_pre12==25 |province_pre12==24 |province_pre12==69;
replace region26_pre12=21 if province_pre12==4 |province_pre12==36 |province_pre12==76 |province_pre12==75;
replace region26_pre12=22 if province_pre12==44 |province_pre12==23 |province_pre12==12 |province_pre12==62;
replace region26_pre12=23 if province_pre12==65 |province_pre12==49 |province_pre12==13 |province_pre12==30;
replace region26_pre12=24 if province_pre12==27 |province_pre12==2 |province_pre12==79;
replace region26_pre12=25 if province_pre12==63 |province_pre12==21;
replace region26_pre12=26 if province_pre12==47 |province_pre12==72 |province_pre12==73|province_pre12==56;

label variable region26_pre12 "26 Regions they lived in before age 12";

tab region26_pre12, gen(region26_pre12_);

*LABOR MARKET VARIABLES;

gen working_men = 0;
replace working_men = 1 if q403a==1|q403b==1;

label variable working_men "Dummy:1 if partner has a job";

gen working = 0;
replace working = 1 if q105d==1|q105e==1|q105f==1;

label variable working "Dummy:1 if woman has a job";

gen work_lastweek =.;
replace work_lastweek = 1 if q105d==1;
replace work_lastweek = 0 if q105d==2;

label variable work_lastweek "Dummy:1 if woman had a job last week";

gen social_security=.;
replace social_security =0 if q105k==0;
replace social_security =1 if q105k>0;
replace social_security =. if q105k==.;
replace social_security = 0 if work_lastweek==0;

label variable social_security "Dummy:1 if woman has social security benefits";

gen agriculture = 0;
replace agriculture = 1 if q105g==1&working==1;
replace agriculture = 0 if work_lastweek==0;

gen service = 0;
replace service = 1 if q105g==3&working==1;
replace service = 0 if work_lastweek==0;

label variable agriculture "Dummy:1 if woman works in agriculture";
label variable service "Dummy:1 if woman works in service";

gen emp_nonagr=0;
replace emp_nonagr=1 if q105g==2 | q105g==3;
replace emp_nonagr = 0 if work_lastweek==0;

label variable emp_nonagr "Dummy:1 if woman works in non-agriculture";

*personal income index;
gen income_land=0;
replace income_land=1 if q106a==1| q106a==2;

gen income_house=0;
replace income_house=1 if q106b==1| q106b==2;

gen income_company=0;
replace income_company=1 if q106c==1| q106c==2;

gen income_vehicle=0;
replace income_vehicle=1 if q106d==1| q106d==2;

gen income_bank=0;
replace income_bank=1 if q106e==1| q106e==2;

gen income_other=0;
replace income_other=1 if q106f==1| q106f==2;

foreach var in 
income_land income_house income_company income_vehicle income_bank income_other{;
egen z_`var'=std(`var');
};
egen z_income=rowmean(z_income_land z_income_house z_income_company z_income_vehicle z_income_bank z_income_other);
drop z_income_land z_income_house z_income_company z_income_vehicle z_income_bank z_income_other;
label variable z_income "z-score: all income variables";
label variable income_land "Dummy:1 if woman has income from owning land";
label variable income_house "Dummy:1 if woman has income from owning a house";
label variable income_company "Dummy:1 if woman has income from owning a company";
label variable income_vehicle "Dummy:1 if woman has income from owning a vehicle";
label variable income_bank "Dummy:1 if woman has money in a bank account";
label variable income_other "Dummy:1 if woman has other income";

**MARRIAGE VARIABLES;
gen marriage_age=q122y_1-year+1;
replace marriage_age=. if q122y_1==9997 | q122y_1==9998;
tab marriage_age;
replace marriage_age=. if marriage_age<=7;

label variable marriage_age "Marriage at first marriage";

gen husband_age=.;
replace husband_age=q123_1;
replace husband_age=. if q123_1==98| q123_1==.a;

label variable husband_age "Husband's age";

gen age_gap=husband_age-marriage_age;

label variable age_gap "Gap between husband and wife's ages";

gen marriage_decision=.;
replace marriage_decision=1 if q125_1==2 | q125_1==3;
replace marriage_decision=0 if q125_1==1 | q125_1==4 | q125_1==5 | q125_1==7;

label variable marriage_decision "Dummy:1 if woman made the marriage decision";

gen divorced=0;
replace divorced=1 if q135_1==2|q135_1==3;
replace divorced=1 if q135_2==2|q135_2==3;
replace divorced=1 if q135_3==2|q135_3==3;
replace divorced=1 if q135_4==2|q135_4==3;
replace divorced=1 if q135_5==2|q135_5==3;
replace divorced=1 if q135_6==2|q135_6==3;
label variable divorced "Dummy:1 if ever divorced or separated";

gen second_marriage=0;
replace second_marriage=1 if q131_2==1|q131_3==1|q131_4==1|q131_5==1|q131_6==1;
label variable second_marriage "Dummy:1 if respondent has been married more than once";

**FERTILITY;
gen ever_given_birth = .;
replace ever_given_birth = 1 if q301 > 0;
replace ever_given_birth = 0 if q301 == 0;
replace ever_given_birth = . if q301 == 99 | q301 == .a;

label variable ever_given_birth "Dummy:1 if woman has ever gavin birth";

gen num_children_female = q303a;
replace num_children_female = 0 if q303a == .;
replace num_children_female = . if q303a == 99;

label variable num_children_female "Number of female children";

gen num_children_male = q303b;
replace num_children_male = 0 if q303b == .;
replace num_children_male = . if q303b == 99;

label variable num_children_male "Number of male children";

gen num_children=num_children_female+num_children_male;
label variable num_children "Number of children";

gen ever_used_contraceptive = .;
replace ever_used_contraceptive = 1 if q305 == 1;
replace ever_used_contraceptive = 0 if q305 == 2;

label variable ever_used_contraceptive "Dummy:1 if woman has ever used contraceptive";

gen partner_disapproves_contra = .;
replace partner_disapproves_contra = 1 if q310 == 1;
replace partner_disapproves_contra = 0 if q310 == 2;

label variable partner_disapproves_contra "Dummy:1 if partner disapproves contraception use";

*GENERATE ATTITUTES MEASURES;
gen agree_notargue=.;
replace agree_notargue=1 if q410a==1;
replace agree_notargue=0 if q410a==2;

gen agree_spend=.;
replace agree_spend=1 if q410b==1;
replace agree_spend=0 if q410b==2;

gen agree_beat=.;
replace agree_beat=1 if q410c==1;
replace agree_beat=0 if q410c==2;

gen agree_division=.;
replace agree_division=1 if q410d==1;
replace agree_division=0 if q410d==2;

gen agree_childbeat=.;
replace agree_childbeat=1 if q410e==1;
replace agree_childbeat=0 if q410e==2;

gen agree_maleresponse=.;
replace agree_maleresponse=1 if q410f==1;
replace agree_maleresponse=0 if q410f==2;

gen agree_obligedsex=.;
replace agree_obligedsex=1 if q410g==1;
replace agree_obligedsex=0 if q410g==2;

gen disagree_notargue=.;
replace disagree_notargue=1 if agree_notargue==0;
replace disagree_notargue=0 if agree_notargue==1;

gen disagree_beat=.;
replace disagree_beat=1 if agree_beat==0;
replace disagree_beat=0 if agree_beat==1;

gen disagree_childbeat=.;
replace disagree_childbeat=1 if agree_childbeat==0;
replace disagree_childbeat=0 if agree_childbeat==1;

gen disagree_maleresponse=.;
replace disagree_maleresponse=1 if agree_maleresponse==0;
replace disagree_maleresponse=0 if agree_maleresponse==1;

gen disagree_obligedsex=.;
replace disagree_obligedsex=1 if agree_obligedsex==0;
replace disagree_obligedsex=0 if agree_obligedsex==1;

label variable agree_notargue "Dummy:1 if thinks a woman should not argue with partners";
label variable agree_spend "Dummy:1 if thinks a woman can spend money as she wants";
label variable agree_beat "Dummy:1 if thinks a husband can beat his wife in some cases";
label variable agree_division "Dummy:1 if thinks there should be division of labor at home";
label variable agree_childbeat "Dummy:1 if thinks a child can be beaten for discipline";
label variable agree_maleresponse "Dummy:1 if thinks woman's behavior is man's responsibility";
label variable agree_obligedsex "Dummy:1 if thinks a woman is obliged to have sexual intercourse with her husband";
label variable disagree_notargue "Dummy:1 if thinks a woman can argue with partners";
label variable disagree_beat "Dummy:1 if thinks a husband cannot beat his wife under any circums.";
label variable disagree_childbeat "Dummy:1 if thinks a child cannot be beaten for discipline";
label variable disagree_maleresponse "Dummy:1 if thinks woman's behavior is not man's responsibility";
label variable disagree_obligedsex "Dummy:1 if thinks a woman is not obliged to have sexual intercourse with her husband";

*GENERATE DOMESTIC VIOLENCE MEASURES;
gen intervene_friends=.;
replace intervene_friends=1 if q501a == 1;
replace intervene_friends=0 if q501a == 2;

gen intervene_family=.;
replace intervene_family=1 if q501b == 1;
replace intervene_family=0 if q501b == 2;

gen intervene_location=.;
replace intervene_location=1 if q501c == 1;
replace intervene_location=0 if q501c == 2;

gen intervene_ignore=.;
replace intervene_ignore=1 if q501d == 1;
replace intervene_ignore=0 if q501d == 2;

gen intervene_otherman=.;
replace intervene_otherman=1 if q501e == 1;
replace intervene_otherman=0 if q501e == 2;

gen intervene_suspicious=.;
replace intervene_suspicious=1 if q501f == 1;
replace intervene_suspicious=0 if q501f == 2;

gen intervene_healthcare=.;
replace intervene_healthcare=1 if q501g == 1;
replace intervene_healthcare=0 if q501g == 2;

gen intervene_clothes=.;
replace intervene_clothes=1 if q501h == 1;
replace intervene_clothes=0 if q501h == 2;

foreach var in friends family healthcare clothes{;
label variable intervene_`var' "Dummy:1 if partner intervenes with `var'";
};
label variable intervene_location "Dummy:1 if partner insists on knowing where she is";
label variable intervene_ignore "Dummy:1 if partner ignore her";
label variable intervene_otherman "Dummy:1 if partner is angry about other man";
label variable intervene_suspicious "Dummy:1 if partner is suspicious that she is unfaithful";

gen refuse_money=.;
replace refuse_money=1 if q502ab == 1;
replace refuse_money=0 if q502ab == 2;

gen took_money=.;
replace took_money=1 if q502ac == 1;
replace took_money=0 if q502ac == 2;

gen insult=.;
replace insult=1 if q503aa == 1;
replace insult=0 if q503aa == 2;

gen humiliate=.;
replace humiliate=1 if q503ab == 1;
replace humiliate=0 if q503ab == 2;

gen threaten=.;
replace threaten=1 if q503ac == 1;
replace threaten=0 if q503ac == 2;

gen slap=.;
replace slap=1 if q504aa == 1;
replace slap=0 if q504aa == 2;

gen push=.;
replace push=1 if q504ab == 1;
replace push=0 if q504ab == 2;

gen hit=.;
replace hit=1 if q504ac == 1;
replace hit=0 if q504ac == 2;

gen kick=.;
replace kick=1 if q504ad == 1;
replace kick=0 if q504ad == 2;

gen choked=.;
replace choked=1 if q504ae == 1;
replace choked=0 if q504ae == 2;

gen forced_sex=.;
replace forced_sex=1 if q505aa == 1;
replace forced_sex=0 if q505aa == 2;

gen forced_sex_fear=.;
replace forced_sex_fear=1 if q505ab == 1;
replace forced_sex_fear=0 if q505ab == 2;

gen humiliated_sex=.;
replace humiliated_sex=1 if q505ac == 1;
replace humiliated_sex=0 if q505ac == 2;

foreach var in insult humiliate threaten slap push hit kick choked{;
label variable `var' "Dummy:1 if a partner ever `var' her";
};

label variable refuse_money "Dummy:1 if a partner ever refused to give her money";

label variable took_money "Dummy:1 if a partner ever `var' her";

label variable forced_sex "Dummy:1 if a partner ever forced her for sex";

label variable forced_sex_fear "Dummy:1 if a partner ever forced her for sex with fear";

label variable humiliated_sex "Dummy:1 if a partner ever humiliated her during sex";

**Ask for help;
gen ask_police=.;
replace ask_police=1 if q708aa==1;
replace ask_police=0 if q708aa==2;

label variable ask_police "Dummy:1 if asked police for help";

gen ask_hospital=.;
replace ask_hospital=1 if q708ac==1;
replace ask_hospital=0 if q708ac==2;

label variable ask_hospital "Dummy:1 if asked hospital for help";

gen mother_violence=.;
replace mother_violence=1 if q806==1;
replace mother_violence=0 if q806==2|q806==3;

label variable mother_violence "Dummy:1 if mother ever faced violence by partner";

gen motherinlaw_violence=.;
replace motherinlaw_violence=1 if q807==1;
replace motherinlaw_violence=0 if q807==2|q807==3;

label variable motherinlaw_violence "Dummy:1 if mother-in-law ever faced violence by partner";

gen partnerfaceddv=.;
replace partnerfaceddv=0 if q809==1;
replace partnerfaceddv=1 if q809==2;

label variable partnerfaceddv "Dummy:1 if partner ever faced violence by his family members";

**GENERATE VIOLENCE VARIABLES FOR ANALYSIS;
gen physical=0;
replace physical=. if q504aa==. & q504ab==. & q504ac==. & q504ad==.& q504ae==. & q507==.;
replace physical=1 if q504aa==1 | q504ab==1 | q504ac==1 | q504ad==1| q504ae==1 & q507==1;

gen sexual=0;
replace sexual=. if q505aa==. & q505ab==. & q505ac==.;
replace sexual=1 if q505aa==1 | q505ab==1 | q505ac==1;

gen financial=0;
replace financial=. if took_money==. & refuse_money==. ;
replace financial=1 if took_money==1 | refuse_money==1 ;

gen emotional=0;
replace emotional=. if q503aa==. & q503ab==. & q503ac==.& intervene_friends==. & intervene_family==. & intervene_location==. & intervene_ignore==. & intervene_otherman==. & intervene_suspicious==. & intervene_healthcare==. & intervene_clothes==.;
replace emotional=1 if q503aa==1 | q503ab==1 | q503ac==1| intervene_friends==1 | intervene_family==1 | intervene_location==1 | intervene_ignore==1 | intervene_otherman==1 | intervene_suspicious==1 | intervene_healthcare==1 | intervene_clothes==1;

label variable physical "Dummy:1 if woman faced any form of physical violence";
label variable sexual "Dummy:1 if woman faced any form of sexual violence";
label variable financial "Dummy:1 if woman faced any form of financial control";
label variable emotional "Dummy:1 if woman faced any form of psychological violence";

*Create z-score a la Kling&Liebman and Katz Metrica;
*Attitudes;
foreach var in 
disagree_notargue disagree_beat disagree_childbeat disagree_maleresponse disagree_obligedsex agree_spend agree_division{;
egen z_`var'=std(`var');
};
egen z_attitudes=rowmean(z_disagree_notargue z_disagree_beat z_disagree_childbeat z_disagree_maleresponse z_disagree_obligedsex z_agree_spend z_agree_division);
drop z_disagree_notargue z_disagree_beat z_disagree_childbeat z_disagree_maleresponse z_disagree_obligedsex z_agree_spend z_agree_division;

*Sexual Violence;
foreach var in 
forced_sex forced_sex_fear humiliated_sex{;
egen z_`var'=std(`var');
};
egen z_sexual=rowmean(z_forced_sex z_forced_sex_fear z_humiliated_sex);
drop z_forced_sex z_forced_sex_fear z_humiliated_sex;

*Physical Violence;
foreach var in 
slap push hit kick choked{;
egen z_`var'=std(`var');
};

egen z_physical=rowmean(z_slap z_push z_hit z_kick z_choked);

drop z_slap z_push z_hit z_kick z_choked;

*Financial Control;
foreach var in 
took_money refuse_money{;
egen z_`var'=std(`var');
};
egen z_financial=rowmean(z_took_money z_refuse_money);
drop z_took_money z_refuse_money;

*Pscyhological violence;
foreach var in 

insult humiliate threaten intervene_friends intervene_family intervene_location intervene_ignore intervene_otherman intervene_suspicious intervene_healthcare intervene_clothes{;
egen z_`var'=std(`var');
};
egen z_emotional=rowmean(z_insult z_humiliate z_threaten z_intervene_friends z_intervene_family z_intervene_location z_intervene_ignore z_intervene_otherman z_intervene_suspicious z_intervene_healthcare z_intervene_clothes);
drop z_insult z_humiliate z_threaten z_intervene_friends z_intervene_family z_intervene_location z_intervene_ignore z_intervene_otherman z_intervene_suspicious z_intervene_healthcare z_intervene_clothes;

label variable z_attitudes "Z-score: all attitudes variables";
label variable z_sexual "Z-score: all sexual violence variables";
label variable z_physical "Z-score: all physical violence variables";
label variable z_financial "Z-score: all finacial control variables";
label variable z_emotional "Z-score: all pscyhological violence or controlling behavior variables";

generate nuts2=. ;
replace nuts2=12 if province_pre12==1;
replace nuts2=24 if province_pre12==2;
replace nuts2=6 if province_pre12==3;
replace nuts2=21 if province_pre12==4;
replace nuts2=18 if province_pre12==5;
replace nuts2=9 if province_pre12==6;
replace nuts2=11 if province_pre12==7;
replace nuts2=19 if province_pre12==8;
replace nuts2=5 if province_pre12==9;
replace nuts2=3 if province_pre12==10;
replace nuts2=7 if province_pre12==11;
replace nuts2=22 if province_pre12==12;
replace nuts2=23 if province_pre12==13;
replace nuts2=8 if province_pre12==14;
replace nuts2=11 if province_pre12==15;
replace nuts2=7 if province_pre12==16;
replace nuts2=3 if province_pre12==17;
replace nuts2=17 if province_pre12==18;
replace nuts2=18 if province_pre12==19;
replace nuts2=5 if province_pre12==20;
replace nuts2=25 if province_pre12==21;
replace nuts2=2 if province_pre12==22;
replace nuts2=22 if province_pre12==23;
replace nuts2=20 if province_pre12==24;
replace nuts2=20 if province_pre12==25;
replace nuts2=7 if province_pre12==26;
replace nuts2=24 if province_pre12==27;
replace nuts2=19 if province_pre12==28;
replace nuts2=19 if province_pre12==29;
replace nuts2=23 if province_pre12==30;
replace nuts2=13 if province_pre12==31;
replace nuts2=11 if province_pre12==32;
replace nuts2=12 if province_pre12==33;
replace nuts2=1 if province_pre12==34;
replace nuts2=4 if province_pre12==35;
replace nuts2=21 if province_pre12==36;
replace nuts2=17 if province_pre12==37;
replace nuts2=15 if province_pre12==38;
replace nuts2=2 if province_pre12==39;
replace nuts2=14 if province_pre12==40;
replace nuts2=8 if province_pre12==41;
replace nuts2=10 if province_pre12==42;
replace nuts2=6 if province_pre12==43;
replace nuts2=22 if province_pre12==44;
replace nuts2=6 if province_pre12==45;
replace nuts2=13 if province_pre12==46;
replace nuts2=26 if province_pre12==47;
replace nuts2=5 if province_pre12==48;
replace nuts2=23 if province_pre12==49;
replace nuts2=14 if province_pre12==50;
replace nuts2=14 if province_pre12==51;
replace nuts2=19 if province_pre12==52;
replace nuts2=19 if province_pre12==53;
replace nuts2=8 if province_pre12==54;
replace nuts2=18 if province_pre12==55;
replace nuts2=26 if province_pre12==56;
replace nuts2=17 if province_pre12==57;
replace nuts2=15 if province_pre12==58;
replace nuts2=2 if province_pre12==59;
replace nuts2=18 if province_pre12==60;
replace nuts2=19 if province_pre12==61;
replace nuts2=22 if province_pre12==62;
replace nuts2=25 if province_pre12==63;
replace nuts2=6 if province_pre12==64;
replace nuts2=23 if province_pre12==65;
replace nuts2=15 if province_pre12==66;
replace nuts2=16 if province_pre12==67;
replace nuts2=14 if province_pre12==68;
replace nuts2=20 if province_pre12==69;
replace nuts2=10 if province_pre12==70;
replace nuts2=14 if province_pre12==71;
replace nuts2=26 if province_pre12==72;
replace nuts2=26 if province_pre12==73;
replace nuts2=16 if province_pre12==74;
replace nuts2=21 if province_pre12==75;
replace nuts2=21 if province_pre12==76;
replace nuts2=8 if province_pre12==77;
replace nuts2=16 if province_pre12==78;
replace nuts2=24 if province_pre12==79;
replace nuts2=13 if province_pre12==80;
replace nuts2=8 if province_pre12==81;

label variable nuts2 "26 regions for childhood region";

**Merge household variables;
merge m:1 HHID using "created/household_data_for_analysis.dta";
drop if _merge==2;
drop _merge;

label variable womenweight "Sampling weights for women";

drop q1* q2* q3* q4* q5* q6* q7* q8* q9*;

drop working qline qregion qregion12 qprovin qdistri qsdist qvill qintd qintm qinty qintnum qresult qvisits qsuperv qsupd qsupm qfedit qfieldd qfieldm qkeyer1 qkeyd1 qkeym1 qkeyer2 qkeyd2 qkeym2 qintc qline1_1 qline1_2 qline1_3 qline1_4 qline1_5 qline1_6 qcard age5 x strata;


save "created/women_data_for_analysis.dta", replace;
