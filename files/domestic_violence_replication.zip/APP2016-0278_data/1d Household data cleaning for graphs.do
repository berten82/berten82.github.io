***Last Updated: 1/24/2017 Stata14
/*==========================================*
Paper:			For Better or for Worse: Education and the Prevalence of Domestic Violence in Turkey

Purpose:        Data cleaning for the household dataset from Turkish National Survey on Domestic Violence against Women (TNSDVW) for producing graphs

To re-run our analysis, please install a folder "Domestic Violence". There should be 5 subfolders in order for do-files to run:

"originals"
"created"
"do files"
"graphs"
"output"

To run the do file all you need to do is to change the path of the working directory in line 34.

The dataset used in this do file is provided by the Turkish Statistical Institute (TSI). Their data availability policy 
prohibits the distribution of data to non-registered users. Researchers have to complete a form 
(http://www.turkstat.gov.tr/UstMenu/body/bilgitalep/MVKullaniciTalepFormu_ENG.pdf), and send it 
to bilgi@tuik.gov.tr by e-mail. Upon receipt of this form, the TSI sends 
the datasets through an ftp server electronically. 

The name of the dataset sent by the TSI will be as follows: TKAA2008HANEDATA????????.sav. Please convert this data in spss
format into Stata format, and save it as "Domestic Violence/originals/household_from_spss.dta" before you run this
do file.

*==========================================*/
clear
set more off 
set matsize 8000
cap log close
#delimit ;

global dir="XXX\Domestic Violence";
cd "$dir";

use "originals\household_from_spss.dta", clear;

*Create unique household ID;
gen HHID = qhclust*1000+qhnumber;
sort HHID;
order HHID;

rename qh03_01 qh03_1;
rename qh03_02 qh03_2;
rename qh03_03 qh03_3;
rename qh03_04 qh03_4;
rename qh03_05 qh03_5;
rename qh03_06 qh03_6;
rename qh03_07 qh03_7;
rename qh03_08 qh03_8;
rename qh03_09 qh03_9;
rename qh06_01 qh06_1;
rename qh06_02 qh06_2;
rename qh06_03 qh06_3;
rename qh06_04 qh06_4;
rename qh06_05 qh06_5;
rename qh06_06 qh06_6;
rename qh06_07 qh06_7;
rename qh06_08 qh06_8;
rename qh06_09 qh06_9;
rename qh07_01 qh07_1;
rename qh07_02 qh07_2;
rename qh07_03 qh07_3;
rename qh07_04 qh07_4;
rename qh07_05 qh07_5;
rename qh07_06 qh07_6;
rename qh07_07 qh07_7;
rename qh07_08 qh07_8;
rename qh07_09 qh07_9;
rename qh11_01 qh11_1;
rename qh11_02 qh11_2;
rename qh11_03 qh11_3;
rename qh11_04 qh11_4;
rename qh11_05 qh11_5;
rename qh11_06 qh11_6;
rename qh11_07 qh11_7;
rename qh11_08 qh11_8;
rename qh11_09 qh11_9;
rename qh10a_01 qh10a_1;
rename qh10a_02 qh10a_2;
rename qh10a_03 qh10a_3;
rename qh10a_04 qh10a_4;
rename qh10a_05 qh10a_5;
rename qh10a_06 qh10a_6;
rename qh10a_07 qh10a_7;
rename qh10a_08 qh10a_8;
rename qh10a_09 qh10a_9;
rename qh10b_01 qh10b_1;
rename qh10b_02 qh10b_2;
rename qh10b_03 qh10b_3;
rename qh10b_04 qh10b_4;
rename qh10b_05 qh10b_5;
rename qh10b_06 qh10b_6;
rename qh10b_07 qh10b_7;
rename qh10b_08 qh10b_8;
rename qh10b_09 qh10b_9;
keep HHID qh03_* qh06_* qh07_* qh10a_* qh10b_* qh11_*;
reshape long qh03_ qh06_ qh07_ qh10a_ qh10b_ qh11_, i(HHID) j(member);

g jhighschool=0;
replace jhighschool=1 if qh10a_==2 & qh11_==1;
replace jhighschool=1 if qh10a_==3 & qh11_==1;
replace jhighschool=1 if qh10a_==4 | qh10a_==5 | qh10a_==6 | qh10a_==7;
replace jhighschool=. if qh10a_==8; 

g male=.;
replace male=1 if qh06_==1;
replace male=0 if qh06_==2;
rename qh07_ age;

label variable age "Age of the individual";
label variable jhighschool "Dummy:1 if the individual completed junior high school";
label variable male "Dummy:1 if the individual is male";
label variable HHID "Household ID";

drop member qh03_ qh06_ qh10a_ qh10b_ qh11_;

save "created/household_data_for_graphs.dta", replace;
