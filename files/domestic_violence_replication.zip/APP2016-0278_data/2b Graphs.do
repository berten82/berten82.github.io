***Last Updated: 1/24/2017 Stata14
/*==========================================*
Paper:			For Better or for Worse: Education and the Prevalence of Domestic Violence in Turkey

Purpose:        Produce the graphs in Figures 2-6

To re-run our analysis, please install a folder "Domestic Violence". There should be 5 subfolders in order for do-files to run:

"originals"
"created"
"do files"
"graphs"
"output"

Before you run this do file, please change the path of the working directory in line 24 and run all of the data cleaning do files.
*==========================================*/

clear
set more off 
set matsize 8000
cap log close
#delimit ;

global dir="XXX\Domestic Violence";
cd "$dir";

global grfont "Georgia";

********FIGURE 2 BALANCED COVARIATES GRAPH;
use "created/women_data_for_analysis.dta", clear;
set more off;

cap prog drop _all;

do "do files\rdprog_cols1_se2.do";

global gbw "61";
global bin "1";
global lim "dif<=60 & dif>=-60";
global xlabel "-60(30)60,";
global ylabel "0(0.2)1,";

rdintgraphtlim region5_pre12_1 dif $bin "$lim" "" "Born after January 1987 (in months), size(3) color(black)" "$ylabel" "$xlabel" /// 
	"" "(a) Childhood Region: West, size(3.5) color(black)" "" "$gbw";
graph save "graphs\West.gph", replace;

rdintgraphtlim region5_pre12_2 dif $bin "$lim" "" "Born after January 1987 (in months), size(3) color(black)" "$ylabel" "$xlabel" ///
	"" "(b) Childhood Region: South, size(3.5) color(black)" "" "$gbw";
graph save "graphs\South.gph", replace;

rdintgraphtlim region5_pre12_3 dif $bin "$lim" "" "Born after January 1987 (in months), size(3) color(black)" "$ylabel" "$xlabel" ///
	"" "(c) Childhood Region: Central, size(3.5) color(black)" "" "$gbw";
graph save "graphs\Central.gph", replace;

rdintgraphtlim region5_pre12_4 dif $bin "$lim" "" "Born after January 1987 (in months), size(3) color(black)" "$ylabel" "$xlabel" ///
	"" "(d) Childhood Region: North, size(3.5) color(black)" "" "$gbw";
graph save "graphs\North.gph", replace;

rdintgraphtlim region5_pre12_5 dif $bin "$lim" "" "Born after January 1987 (in months), size(3) color(black)" "$ylabel" "$xlabel" ///
	"" "(e) Childhood Region: East, size(3.5) color(black)" "" "$gbw";
graph save "graphs\East.gph", replace;

rdintgraphtlim rural_pre12 dif $bin "$lim" "" "Born after January 1987 (in months), size(3) color(black)" "$ylabel" "$xlabel" ///
	"" "(f) Childhood Region: Rural, size(3.5) color(black)" "" "$gbw";
graph save "graphs\Rural.gph", replace;

global ylabel "0(0.2)0.4,";

rdintgraphtlim noturkish dif $bin "$lim" "" "Born after January 1987 (in months), size(3) color(black)" "$ylabel" "$xlabel" ///
	"" "(g) Non-Turkish Speaker, size(3.5) color(black)" "" "$gbw";
graph save "graphs\Noturkish.gph", replace;

global ylabel "0(0.2)1,";

rdintgraphtlim mother_violence dif $bin "$lim" "" "Born after January 1987 (in months), size(3) color(black)" "$ylabel" "$xlabel" ///
	"" "(h) Mother faced domestic violence, size(3.5) color(black)" "" "$gbw";
graph save "graphs\Mother.gph", replace;

graph combine "graphs\West.gph" "graphs\South.gph" "graphs\Central.gph" "graphs\North.gph" "graphs\East.gph" "graphs\Rural.gph" ///
	"graphs\Noturkish.gph" "graphs\Mother.gph", col(4) imargin(small) graphregion(color(white) lcolor(white) lwidth(thick)) ///
	ysize(3) xsize(5) saving("graphs\Figure2.gph", replace);

graph export "graphs\Figure2.eps", replace font($grfont);

********FIGURE 3 RD TREATMENT EFFECTS ON RELATIONSHIP STATUS;
use "created/women_data_for_analysis.dta", clear;
set more off;

cap prog drop _all;

do "do files\rdprog_cols1_se2.do";

global gbw "61";
global bin "1";
global lim "dif<=60 & dif>=-60";
global xlabel "-60(30)60,";
global ylabel "0(0.2)1,";

rdintgraphtlim rel dif $bin "$lim" "" "Born after January 1987 (in months), size(3.5) color(black)" "$ylabel" "$xlabel" /// 
	"" "(a) Ever Had a Relationship, size(4.5) color(black)" "" "$gbw";
graph save "graphs\Rel.gph", replace;

rdintgraphtlim married dif $bin "$lim" "" "Born after January 1987 (in months), size(3.5) color(black)" "$ylabel" "$xlabel" /// 
	"" "(b) Ever Married, size(4.5) color(black)" "" "$gbw";
graph save "graphs\Married.gph", replace;

graph combine "graphs\Rel.gph" "graphs\Married.gph", col(2) imargin(small) graphregion(color(white) lcolor(white) lwidth(thick)) ///
	ysize(1.75) xsize(3.5) saving("graphs\Figure3.gph", replace);

graph export "graphs\Figure3.eps", replace font($grfont);

********FIGURE 4 RD TREATMENT EFFECTS ON JUNIOR HIGH SCHOOL COMPLETION;
use "created/household_data_for_graphs.dta", clear;

keep if male==0;
do "do files\rdprog_cols1_se2_cutoff_reverse.do";
global xlabel "27(1)16,";
global lim "age<=27 & age>=16";
global ylabel "0.2(0.1)1,";
global bin "2";
global gbw "1.9";
rdintgraphtlim jhighschool age $bin "$lim" "" "Age, size(3.5) color(black)" "$ylabel" "$xlabel" "" "Women with Completed Junior High School, size(4) color(black)" "" "$gbw";
graph save "graphs\Women_jhigh.gph", replace;

use "created/household_data_for_graphs.dta", clear;

keep if male==1;
do "do files\rdprog_cols1_se2_cutoff_reverse.do";
global xlabel "27(1)16,";
global lim "age<=27 & age>=16";
global ylabel "0.2(0.1)1,";
global bin "2";
global gbw "1.9";
rdintgraphtlim jhighschool age $bin "$lim" "" "Age, size(3.5) color(black)" "$ylabel" "$xlabel" "" "Men with Completed Junior High School, size(4) color(black)" "" "$gbw";
graph save "graphs\Men_jhigh.gph", replace;

graph combine "graphs\Women_jhigh.gph" "graphs\Men_jhigh.gph", col(2) imargin(small) graphregion(color(white) lcolor(white) lwidth(thick)) ///
	ysize(1.75) xsize(3.5) title("Panel A: 2008 TNSDVW Household Sample", size(3.5) color(black)) saving("graphs\Fig4_panelA.gph", replace);

use "created/hlfs2014_for_graphs.dta", clear;

keep if male==0;
do "do files\rdprog_cols1_se2_mod.do";
global lim "dif<=60 & dif>=-60";
global xlabel "-60(30)60,";
global ylabel "0.3(0.1)1,";
global bin "1";
global gbw "60";

rdintgraphtlim jhighschool dif $bin "$lim" "" "Born after January 1987 (in months), size(3.5) color(black)" "$ylabel" "$xlabel" "" "Women with Completed Junior High School, size(4) color(black)" "" "$gbw";
graph save "graphs\Women_jhigh_14.gph", replace;

use "created/hlfs2014_for_graphs.dta", clear;

keep if male==1;
do "do files\rdprog_cols1_se2_mod.do";
global lim "dif<=60 & dif>=-60";
global xlabel "-60(30)60,";
global ylabel "0.3(0.1)1,";
global bin "1";
global gbw "60";

rdintgraphtlim jhighschool dif $bin "$lim" "" "Born after January 1987 (in months), size(3.5) color(black)" "$ylabel" "$xlabel" "" "Men with Completed Junior High School, size(4) color(black)" "" "$gbw";
graph save "graphs\Men_jhigh_14.gph", replace;

graph combine "graphs\Women_jhigh_14.gph" "graphs\Men_jhigh_14.gph", col(2) imargin(small) graphregion(color(white) lcolor(white) lwidth(thick)) ///
	ysize(1.75) xsize(3.5) title("Panel B: 2014 HLFS Data", size(3.5) color(black)) saving("graphs\Fig4_panelB.gph", replace);

graph combine "graphs\Fig4_panelA.gph" "graphs\Fig4_panelB.gph", col(1) imargin(small) graphregion(color(white) lcolor(white) lwidth(thick)) ///
	ysize(3) xsize(3.5) saving("graphs\Figure4.gph", replace);
	
graph export "graphs\Figure4.eps", replace font($grfont);

********FIGURE 5 TREATMENT AND PLACEBO GRAPH;
use "created/women_data_for_analysis.dta", clear;
set more off;

cap prog drop _all;

do "do files\rdprog_cols1_se2.do";

global gbw "61";
global bin "1";
global lim "dif<=60 & dif>=-60";
global xlabel "-60(30)60,";
global ylabel "0.3(0.1)1,";

rdintgraphtlim jhighschool dif $bin "$lim" "" "Born after January 1987 (in months), size(3.5) color(black)" "$ylabel" "$xlabel" /// 
	"" "2008 TNSDVW Survey, size(4) color(black)" "" "$gbw";
graph save "graphs\Jhigh.gph", replace;

global ylabel "0(0.1)0.6,";

rdintgraphtlim work_lastweek dif $bin "$lim" "" "Born after January 1987 (in months), size(3.5) color(black)" "$ylabel" "$xlabel" /// 
	"" "2008 TNSDVW Survey, size(4) color(black)" "" "$gbw";
graph save "graphs\Employed.gph", replace;



use "created/hlfs2014_for_graphs.dta", clear;

keep if male==0;
do "do files\rdprog_cols1_se2.do";
global lim "dif2<=60 & dif2>=-60";
global xlabel "-60(30)60,";
global ylabel "0.3(0.1)1,";
global bin "1";
global gbw "60";

rdintgraphtlim jhighschool dif2 $bin "$lim" "" "Born after January 1993 (in months), size(3.5) color(black)" "$ylabel" "$xlabel" ///
	"" "2014 HLFS Survey, size(4) color(black)" "" "$gbw";
graph save "graphs\Jhigh_placebo.gph", replace;

global ylabel "0(0.1)0.6,";
rdintgraphtlim waged dif2 $bin "$lim" "" "Born after January 1993 (in months), size(3.5) color(black)" "$ylabel" "$xlabel" ///
	"" "2014 HLFS Survey, size(4) color(black)" "" "$gbw";
	

graph save "graphs\Employed_placebo.gph", replace;


graph combine "graphs\Jhigh.gph" "graphs\Jhigh_placebo.gph", col(2) imargin(small) graphregion(color(white) lcolor(white) lwidth(thick)) ///
	ysize(1.75) xsize(3.5) title("Panel A: Completed Junior High School", size(4) color(black)) saving("graphs\Fig5_panelA.gph", replace);
	
graph combine "graphs\Employed.gph" "graphs\Employed_placebo.gph", col(2) imargin(small) graphregion(color(white) lcolor(white) lwidth(thick)) ///
	ysize(1.75) xsize(3.5) title("Panel B: Propensity to Work", size(4) color(black)) saving("graphs\Fig5_panelB.gph", replace);

graph combine "graphs\Fig5_panelA.gph" "graphs\Fig5_panelB.gph", col(1) imargin(small) graphregion(color(white) lcolor(white) lwidth(thick)) ///
	ysize(5) xsize(3.5) saving("graphs\Figure5.gph", replace);
	
graph export "graphs\Figure5.eps", replace font($grfont);

*/
********FIGURE 6 YEARS OF SCHOOLING, RURAL-URBAN GRAPH;

use "created/women_data_for_analysis.dta", clear;
set more off;

cap prog drop _all;

do "do files\rdprog_cols1_se2.do";

global gbw "61";
global bin "1";
global lim "dif<=60 & dif>=-60";
global xlabel "-60(30)60,";
global ylabel "0(4)12,";

keep if rural_pre12==1&rel==1;

rdintgraphtlim schooling dif $bin "$lim" "" "" "$ylabel" "$xlabel" "" "Rural, size(3.5) color(black)" "" "$gbw";
graph save "graphs\Schooling_rural.gph", replace;


use "created/women_data_for_analysis.dta", clear;
set more off;

cap prog drop _all;

do "do files\rdprog_cols1_se2.do";

global gbw "61";
global bin "1";
global lim "dif<=60 & dif>=-60";
global xlabel "-60(30)60,";
global ylabel "0(4)12,";

keep if rural_pre12==0&rel==1;

rdintgraphtlim schooling dif $bin "$lim" "" "" "$ylabel" "$xlabel" "alt" "Urban, size(3.5) color(black)" "" "$gbw";
graph save "graphs\Schooling_urban.gph", replace;

graph combine "graphs\Schooling_rural.gph" "graphs\Schooling_urban.gph", col(2) imargin(1 1 1 1) graphregion(color(white)) ///
	ysize(3) xsize(5)  l2title("", size(3)) saving("graphs\Schooling.gph", replace) b1title("", size(2.6) color(black)) title((a) Years of schooling, size(3) color(black));

**Physical violence;
use "created/women_data_for_analysis.dta", clear;
set more off;

cap prog drop _all;

do "do files\rdprog_cols1_se2.do";

global gbw "61";
global bin "1";
global lim "dif<=60 & dif>=-60";
global xlabel "-60(30)60,";
global ylabel "-0.4(0.2)1,";

keep if rural_pre12==1&rel==1;

rdintgraphtlim z_physical dif $bin "$lim" "" "" "$ylabel" "$xlabel" "" "Rural, size(3.5) color(black)" "" "$gbw";
graph save "graphs\Physical_rural.gph", replace;


use "created/women_data_for_analysis.dta", clear;
set more off;

cap prog drop _all;

do "do files\rdprog_cols1_se2.do";

global gbw "61";
global bin "1";
global lim "dif<=60 & dif>=-60";
global xlabel "-60(30)60,";
global ylabel "-0.4(0.2)1,";

keep if rural_pre12==0&rel==1;

rdintgraphtlim z_physical dif $bin "$lim" "" "" "$ylabel" "$xlabel" "alt" "Urban, size(3.5) color(black)" "" "$gbw";
graph save "graphs\Physical_urban.gph", replace;

graph combine "graphs\Physical_rural.gph" "graphs\Physical_urban.gph", col(2) imargin(1 1 1 1) graphregion(color(white)) ///
	ysize(3) xsize(5)  l2title("", size(3)) saving("graphs\Physical.gph", replace) b1title("", size(2.6) color(black)) title((b) Physical violence index, size(3) color(black));

**Sexual violence;
use "created/women_data_for_analysis.dta", clear;
set more off;

cap prog drop _all;

do "do files\rdprog_cols1_se2.do";

global gbw "61";
global bin "1";
global lim "dif<=60 & dif>=-60";
global xlabel "-60(30)60,";
global ylabel "-0.4(0.2)1,";

keep if rural_pre12==1&rel==1;

rdintgraphtlim z_sexual dif $bin "$lim" "" "" "$ylabel" "$xlabel" "" "Rural, size(3.5) color(black)" "" "$gbw";
graph save "graphs\Sexual_rural.gph", replace;


use "created/women_data_for_analysis.dta", clear;
set more off;

cap prog drop _all;

do "do files\rdprog_cols1_se2.do";

global gbw "61";
global bin "1";
global lim "dif<=60 & dif>=-60";
global xlabel "-60(30)60,";
global ylabel "-0.4(0.2)1,";

keep if rural_pre12==0&rel==1;

rdintgraphtlim z_sexual dif $bin "$lim" "" "" "$ylabel" "$xlabel" "alt" "Urban, size(3.5) color(black)" "" "$gbw";
graph save "graphs\Sexual_urban.gph", replace;

graph combine "graphs\Sexual_rural.gph" "graphs\Sexual_urban.gph", col(2) imargin(1 1 1 1) graphregion(color(white)) ///
	ysize(3) xsize(5)  l2title("", size(3)) saving("graphs\Sexual.gph", replace) b1title("", size(2.6) color(black)) title((c) Sexual violence index, size(3) color(black));
	
**Psychological violence or controlling behavior;
use "created/women_data_for_analysis.dta", clear;
set more off;

cap prog drop _all;

do "do files\rdprog_cols1_se2.do";

global gbw "61";
global bin "1";
global lim "dif<=60 & dif>=-60";
global xlabel "-60(30)60,";
global ylabel "-0.4(0.2)1,";

keep if rural_pre12==1&rel==1;

rdintgraphtlim z_emotional dif $bin "$lim" "" "" "$ylabel" "$xlabel" "" "Rural, size(3.5) color(black)" "" "$gbw";
graph save "graphs\Emotional_rural.gph", replace;


use "created/women_data_for_analysis.dta", clear;
set more off;

cap prog drop _all;

do "do files\rdprog_cols1_se2.do";

global gbw "61";
global bin "1";
global lim "dif<=60 & dif>=-60";
global xlabel "-60(30)60,";
global ylabel "-0.4(0.2)1,";

keep if rural_pre12==0&rel==1;

rdintgraphtlim z_emotional dif $bin "$lim" "" "" "$ylabel" "$xlabel" "alt" "Urban, size(3.5) color(black)" "" "$gbw";
graph save "graphs\Emotional_urban.gph", replace;

graph combine "graphs\Emotional_rural.gph" "graphs\Emotional_urban.gph", col(2) imargin(1 1 1 1) graphregion(color(white)) ///
	ysize(3) xsize(5)  l2title("", size(3)) saving("graphs\Emotional.gph", replace) b1title("", size(2.6) color(black)) title((d) Psychological violence index, size(3) color(black));
	
	
graph combine "graphs\Schooling.gph" "graphs\Physical.gph" "graphs\Sexual.gph" "graphs\Emotional.gph", col(2) imargin(small) graphregion(color(white) lcolor(white) lwidth(thick)) ///
	ysize(3) xsize(3.5) b1title("Born after January 1987 (in months)", size(2) color(black)) saving("graphs\Figure6.gph", replace);

graph export "graphs\Figure6.eps", replace font($grfont);



