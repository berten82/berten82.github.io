***Last Updated: 1/24/2017 using Stata14
/*==========================================*
Paper:			For Better or for Worse: Education and the Prevalence of Domestic Violence in Turkey

Purpose:        Produce the results in Tables 1-3 and Online Appendix Tables A1-A13.

To re-run our analysis, please install a folder "Domestic Violence". There should be 5 subfolders in order for do-files to run:

"originals"
"created"
"do files"
"graphs"
"output"

Before you run this do file, please change the path of the working directory in line 24 and run all of the data cleaning do files.
*==========================================*/

clear
set more off 
set matsize 8000
cap log close
#delimit ;

global dir="XXX\Domestic Violence";
cd "$dir";

use "created/women_data_for_analysis.dta", clear;
log using "output/results.log", replace;

global contr1="month_* noturkish region26_pre12_* rural_pre12";
global contr2="month_* noturkish region26_pre12_* rural";
global se "cluster modate";	
global slvl "starlevels(* 0.10 ** 0.05 *** 0.01)";

********** IMPORTANT NOTE: Prior to running the code, please install rdrobust from SSC. In particular, install the package st0366 from http://www.stata-journal.com/software/sj14-4.;

********** MAIN TABLES;

********** TABLE 1: SUMMARY STATISTICS FOR 16-26 YEAR-OLD WOMEN WHO EVER HAD A RELATIONSHIP;

foreach x in schooling jhighschool highschool primaryschool work_lastweek emp_nonagr service agriculture social_security z_income marriage_age marriage_decision working_men schooling_partner schooling_gap age_gap husband_age z_malereligious motherinlaw_violence partnerfaceddv divorced second_marriage z_asset agree_notargue agree_spend agree_beat agree_childbeat agree_division agree_maleresponse agree_obligedsex z_attitudes z_physical z_sexual z_emotional z_financial rural_pre12 rural noturkish mother_violence{; 

regress `x' dif if abs(dif)<61 & rel==1; 
sum `x' [aw=womenweight] if abs(dif)<61 & rel==1;
outreg2 using "output/t1_`x'", excel replace ctitle(Mean) addstat(Mean, r(mean), Standard deviation, r(sd)) adec(2) nonotes nocons;
};

foreach x in schooling jhighschool highschool primaryschool work_lastweek emp_nonagr service agriculture social_security z_income marriage_age marriage_decision working_men schooling_partner schooling_gap age_gap husband_age z_malereligious motherinlaw_violence partnerfaceddv divorced second_marriage z_asset agree_notargue agree_spend agree_beat agree_childbeat agree_division agree_maleresponse agree_obligedsex z_attitudes z_physical z_sexual z_emotional z_financial rural_pre12 rural noturkish mother_violence{;

regress `x' dif if abs(dif)<61 & rel==1 & rural_pre12==1;
sum `x' [aw=womenweight] if abs(dif)<61 & rel==1 & rural_pre12==1;
outreg2 using "output/t1_`x'", excel append ctitle(Mean) addstat(Mean, r(mean), Standard deviation, r(sd)) adec(2) nonotes nocons;
};

foreach x in schooling jhighschool highschool primaryschool work_lastweek emp_nonagr service agriculture social_security z_income marriage_age marriage_decision working_men schooling_partner schooling_gap age_gap husband_age z_malereligious motherinlaw_violence partnerfaceddv divorced second_marriage z_asset agree_notargue agree_spend agree_beat agree_childbeat agree_division agree_maleresponse agree_obligedsex z_attitudes z_physical z_sexual z_emotional z_financial rural_pre12 rural noturkish mother_violence{;

regress `x' dif if abs(dif)<61 & rel==1 & rural_pre12==0;
sum `x' [aw=womenweight] if abs(dif)<61 & rel==1 & rural_pre12==0;
outreg2 using "output/t1_`x'", excel append ctitle(Mean) addstat(Mean, r(mean), Standard deviation, r(sd)) adec(2) nonotes nocons;
};

svyset HHID [pw=womenweight], strata(nuts2);

foreach x in schooling jhighschool highschool primaryschool work_lastweek emp_nonagr service agriculture social_security z_income marriage_age marriage_decision working_men schooling_partner schooling_gap age_gap husband_age z_malereligious motherinlaw_violence partnerfaceddv divorced second_marriage z_asset agree_notargue agree_spend agree_beat agree_childbeat agree_division agree_maleresponse agree_obligedsex z_attitudes z_physical z_sexual z_emotional z_financial rural noturkish mother_violence{;

svy: mean `x' if abs(dif)<61 & rel==1, over(rural_pre12);
lincom [`x']0 - [`x']1;
local tstat=r(estimate)/r(se);
local pval = tprob(r(df), abs(`tstat'));
outreg2 using "output/t1_`x'", excel append ctitle(Difference) addstat(difference, r(estimate), standard, r(se), pval, `pval') adec(2) nonotes nocons;
};

********** TABLE 2: RD TREATMENT EFFECTS ON SCHOOLING; 
********** TABLE 2, PANEL A: SAMPLE OF ALL WOMEN;
foreach x in schooling jhighschool highschool primaryschool{;

**linear RD, h bandwidth, with controls;
rdrobust `x' dif, bwselect(IK);
regress `x' after1986 di1* $contr1 [aw=womenweight] if abs(dif)<e(h_bw), vce($se);
outreg2 using "output/t2_`x'", excel  replace ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;
	
**quadratic RD, h bandwidth, with controls;
rdrobust `x' dif, bwselect(IK);
regress `x' after1986 di1* di2* $contr1 [aw=womenweight] if abs(dif)<e(h_bw), vce($se);
outreg2 using "output/t2_`x'", excel  append ctitle(Quadratic RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h/2 bandwidth, with controls;
rdrobust `x' dif, bwselect(IK);
regress `x' after1986 di1* $contr1 [aw=womenweight] if abs(dif)<e(h_bw)/2, vce($se);
outreg2 using "output/t2_`x'", excel  append ctitle(Linear RD, h/2 bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

** linear RD, h*2 bandwidth, with controls;
rdrobust `x' dif, bwselect(IK);
regress `x' after1986 di1* $contr1 [aw=womenweight] if abs(dif)<e(h_bw)*2, vce($se);
outreg2 using "output/t2_`x'", excel  append ctitle(Linear RD, 2h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**reporting bandwidth;
rdrobust `x' dif, bwselect(IK);
outreg2 using "output/t2_`x'", excel append ctitle(Bandwidth) addstat(BW Loc. Poly. (h), e(h_bw)) adec(0) nonotes nocons;

**reporting mean;
rdrobust `x' dif, bwselect(IK);
sum `x' [aw=womenweight] if abs(dif)<e(h_bw);
outreg2 using "output/t2_`x'", excel append ctitle(Mean) addstat(Mean, r(mean)) adec(2) nonotes nocons;
};


********** TABLE 2, PANEL B: SAMPLE OF WOMEN WHO HAVE HAD A RELATIONSHIP;

foreach x in schooling jhighschool highschool primaryschool{;

**linear RD, h bandwidth, with controls;
rdrobust `x' dif if rel==1, bwselect(IK);
regress `x' after1986 di1* $contr1 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1, vce($se);
outreg2 using "output/t2_`x'", excel  append ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;
	
**quadratic RD, h bandwidth, with controls;
rdrobust `x' dif if rel==1, bwselect(IK);
regress `x' after1986 di1* di2* $contr1 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1, vce($se);
outreg2 using "output/t2_`x'", excel  append ctitle(Quadratic RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h/2 bandwidth, with controls;
rdrobust `x' dif if rel==1, bwselect(IK);
regress `x' after1986 di1* $contr1 [aw=womenweight] if abs(dif)<e(h_bw)/2 & rel==1, vce($se);
outreg2 using "output/t2_`x'", excel  append ctitle(Linear RD, h/2 bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

** linear RD, h*2 bandwidth, with controls;
rdrobust `x' dif if rel==1, bwselect(IK);
regress `x' after1986 di1* $contr1 [aw=womenweight] if abs(dif)<e(h_bw)*2 & rel==1, vce($se);
outreg2 using "output/t2_`x'", excel  append ctitle(Linear RD, 2h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**reporting bandwidth;
rdrobust `x' dif if rel==1, bwselect(IK);
outreg2 using "output/t2_`x'", excel append ctitle(Bandwidth) addstat(BW Loc. Poly. (h), e(h_bw)) adec(0) nonotes nocons;

**reporting mean;
rdrobust `x' dif if rel==1, bwselect(IK);
sum `x' [aw=womenweight] if abs(dif)<e(h_bw) & rel==1;
outreg2 using "output/t2_`x'", excel append ctitle(Mean) addstat(Mean, r(mean)) adec(2) nonotes nocons;
};


********** TABLE 3: RD TREATMENT EFFECTS ON SCHOOLING BY REGION OF CHILDHOOD;
********** TABLE 3, PANEL A: RURAL CHILDHOOD REGION; 

foreach x in schooling jhighschool{;

**linear RD, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
regress `x' after1986 di1* $contr2 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1& rural_pre12==1, vce($se);
outreg2 using "output/t3_`x'", excel  replace ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;
	
**quadratic RD, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
regress `x' after1986 di1* di2* $contr2 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1& rural_pre12==1, vce($se);
outreg2 using "output/t3_`x'", excel  append ctitle(Quadratic RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h/2 bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
regress `x' after1986 di1* $contr2 [aw=womenweight] if abs(dif)<e(h_bw)/2 & rel==1& rural_pre12==1, vce($se);
outreg2 using "output/t3_`x'", excel  append ctitle(Linear RD, h/2 bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

** linear RD, h*2 bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
regress `x' after1986 di1* $contr2 [aw=womenweight] if abs(dif)<e(h_bw)*2 & rel==1& rural_pre12==1, vce($se);
outreg2 using "output/t3_`x'", excel  append ctitle(Linear RD, 2h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**reporting bandwidth;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
outreg2 using "output/t3_`x'", excel append ctitle(Bandwidth) addstat(BW Loc. Poly. (h), e(h_bw)) adec(0) nonotes nocons;

**reporting mean;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
sum `x' [aw=womenweight] if abs(dif)<e(h_bw) & rural_pre12==1 & rel==1;
outreg2 using "output/t3_`x'", excel append ctitle(Mean) addstat(Mean, r(mean)) adec(2) nonotes nocons;
};

********** TABLE 3, PANEL B: URBAN CHILDHOOD REGION;

foreach x in schooling jhighschool{;

**linear RD, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==0, bwselect(IK);
regress `x' after1986 di1* $contr2 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1& rural_pre12==0, vce($se);
outreg2 using "output/t3_`x'", excel  append ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;
	
**quadratic RD, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==0, bwselect(IK);
regress `x' after1986 di1* di2* $contr2 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1& rural_pre12==0, vce($se);
outreg2 using "output/t3_`x'", excel  append ctitle(Quadratic RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h/2 bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==0, bwselect(IK);
regress `x' after1986 di1* $contr2 [aw=womenweight] if abs(dif)<e(h_bw)/2 & rel==1& rural_pre12==0, vce($se);
outreg2 using "output/t3_`x'", excel  append ctitle(Linear RD, h/2 bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

** linear RD, h*2 bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==0, bwselect(IK);
regress `x' after1986 di1* $contr2 [aw=womenweight] if abs(dif)<e(h_bw)*2 & rel==1& rural_pre12==0, vce($se);
outreg2 using "output/t3_`x'", excel  append ctitle(Linear RD, 2h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**reporting bandwidth;
rdrobust `x' dif if rel==1& rural_pre12==0, bwselect(IK);
outreg2 using "output/t3_`x'", excel append ctitle(Bandwidth) addstat(BW Loc. Poly. (h), e(h_bw)) adec(0) nonotes nocons;

**reporting mean;
rdrobust `x' dif if rel==1& rural_pre12==0, bwselect(IK);
sum `x' [aw=womenweight] if abs(dif)<e(h_bw) & rural_pre12==0 & rel==1;
outreg2 using "output/t3_`x'", excel append ctitle(Mean) addstat(Mean, r(mean)) adec(2) nonotes nocons;
};


********** TABLE 4: EDUCATION EFFECTS ON DOMESTIC VIOLENCE BY CHILDHOOD REGION;

foreach x in z_physical z_sexual z_emotional z_financial{;

**OLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1, bwselect(IK);
regress `x' schooling $contr1 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1, vce($se);
outreg2 using "output/t4_`x'", excel  replace ctitle(OLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h bandwidth, with controls;
rdrobust `x' dif if rel==1, bwselect(IK);
regress `x' after1986 di1* $contr1 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1, vce($se);
outreg2 using "output/t4_`x'", excel  append ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD-2SLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1, bwselect(IK);
ivregress 2sls `x' (schooling=after1986) di1* $contr1 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1, vce($se);
outreg2 using "output/t4_`x'", excel  append ctitle(Linear RD-2SLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**OLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
regress `x' schooling $contr1 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1& rural_pre12==1, vce($se);
outreg2 using "output/t4_`x'", excel  append ctitle(OLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
regress `x' after1986 di1* $contr2 [aw=womenweight] if abs(dif)<e(h_bw) & rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/t4_`x'", excel  append ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD-2SLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
ivregress 2sls `x' (schooling=after1986) di1* $contr2 [aw=womenweight] if abs(dif)<e(h_bw) &  rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/t4_`x'", excel  append ctitle(Linear RD-2SLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**reporting bandwidth;
rdrobust `x' dif if rel==1, bwselect(IK);
outreg2 using "output/t4_`x'", excel append ctitle(Bandwidth) addstat(BW Loc. Poly. (h), e(h_bw)) adec(0) nonotes nocons;

rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
outreg2 using "output/t4_`x'", excel append ctitle(Bandwidth) addstat(BW Loc. Poly. (h), e(h_bw)) adec(0) nonotes nocons;

**reporting mean;
rdrobust `x' dif if rel==1, bwselect(IK);
sum `x' [aw=womenweight] if abs(dif)<e(h_bw) & rel==1;
outreg2 using "output/t4_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;

rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
sum `x' [aw=womenweight] if abs(dif)<e(h_bw) & rural_pre12==1 & rel==1;
outreg2 using "output/t4_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;
};


********** TABLE 5: EDUCATION EFFECTS ON GENDER AND DOMESTIC VIOLENCE ATTITUDES BY CHILDHOOD REGION;

use "created/women_data_for_analysis.dta", clear;
global contr1="month_* noturkish region26_pre12_* rural_pre12";
global contr2="month_* noturkish region26_pre12_* rural";
global se "cluster modate";	
global slvl "starlevels(* 0.10 ** 0.05 *** 0.01)";

foreach x in agree_notargue agree_spend agree_beat agree_division agree_childbeat agree_maleresponse agree_obligedsex z_attitudes{;

**OLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1, bwselect(IK);
regress `x' schooling $contr1 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1, vce($se);
outreg2 using "output/t5_`x'", excel  replace ctitle(OLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h bandwidth, with controls;
rdrobust `x' dif if rel==1, bwselect(IK);
regress `x' after1986 di1* $contr1 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1, vce($se);
outreg2 using "output/t5_`x'", excel  append ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD-2SLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1, bwselect(IK);
ivregress 2sls `x' (schooling=after1986) di1* $contr1 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1, vce($se);
outreg2 using "output/t5_`x'", excel  append ctitle(Linear RD-2SLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**OLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
regress `x' schooling $contr1 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1& rural_pre12==1, vce($se);
outreg2 using "output/t5_`x'", excel  append ctitle(OLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
regress `x' after1986 di1* $contr2 [aw=womenweight] if abs(dif)<e(h_bw) & rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/t5_`x'", excel  append ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD-2SLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
ivregress 2sls `x' (schooling=after1986) di1* $contr2 [aw=womenweight] if abs(dif)<e(h_bw) &  rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/t5_`x'", excel  append ctitle(Linear RD-2SLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**reporting bandwidth;
rdrobust `x' dif if rel==1, bwselect(IK);
outreg2 using "output/t5_`x'", excel append ctitle(Bandwidth) addstat(BW Loc. Poly. (h), e(h_bw)) adec(0) nonotes nocons;

rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
outreg2 using "output/t5_`x'", excel append ctitle(Bandwidth) addstat(BW Loc. Poly. (h), e(h_bw)) adec(0) nonotes nocons;

**reporting mean;
rdrobust `x' dif if rel==1, bwselect(IK);
sum `x' [aw=womenweight] if abs(dif)<e(h_bw) & rel==1;
outreg2 using "output/t5_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;

rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
sum `x' [aw=womenweight] if abs(dif)<e(h_bw) & rural_pre12==1 & rel==1;
outreg2 using "output/t5_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;
};

********** TABLE 6: EDUCATION EFFECTS ON LABOR MARKET OUTCOMES BY CHILDHOOD REGION;

foreach x in work_lastweek emp_nonagr service agriculture social_security z_income{;

**OLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1, bwselect(IK);
regress `x' schooling $contr1 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1, vce($se);
outreg2 using "output/t6_`x'", excel  replace ctitle(OLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h bandwidth, with controls;
rdrobust `x' dif if rel==1, bwselect(IK);
regress `x' after1986 di1* $contr1 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1, vce($se);
outreg2 using "output/t6_`x'", excel  append ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD-2SLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1, bwselect(IK);
ivregress 2sls `x' (schooling=after1986) di1* $contr1 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1, vce($se);
outreg2 using "output/t6_`x'", excel  append ctitle(Linear RD-2SLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**OLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
regress `x' schooling $contr1 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1& rural_pre12==1, vce($se);
outreg2 using "output/t6_`x'", excel  append ctitle(OLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
regress `x' after1986 di1* $contr2 [aw=womenweight] if abs(dif)<e(h_bw) & rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/t6_`x'", excel  append ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD-2SLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
ivregress 2sls `x' (schooling=after1986) di1* $contr2 [aw=womenweight] if abs(dif)<e(h_bw) &  rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/t6_`x'", excel  append ctitle(Linear RD-2SLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**reporting bandwidth;
rdrobust `x' dif if rel==1, bwselect(IK);
outreg2 using "output/t6_`x'", excel append ctitle(Bandwidth) addstat(BW Loc. Poly. (h), e(h_bw)) adec(0) nonotes nocons;

rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
outreg2 using "output/t6_`x'", excel append ctitle(Bandwidth) addstat(BW Loc. Poly. (h), e(h_bw)) adec(0) nonotes nocons;

**reporting mean;
rdrobust `x' dif if rel==1, bwselect(IK);
sum `x' [aw=womenweight] if abs(dif)<e(h_bw) & rel==1;
outreg2 using "output/t6_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;

rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
sum `x' [aw=womenweight] if abs(dif)<e(h_bw) & rural_pre12==1 & rel==1;
outreg2 using "output/t6_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;
};


********** TABLE 7: EDUCATION EFFECTS ON PARTNER AND RELATIONSHIP CHARACTERISTICS BY CHILDHOOD REGION;

foreach x in marriage_age marriage_decision working_men schooling_partner schooling_gap age_gap husband_age z_malereligious motherinlaw_violence partnerfaceddv divorced second_marriage z_asset{;

**OLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1, bwselect(IK);
regress `x' schooling $contr1 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1, vce($se);
outreg2 using "output/t7_`x'", excel  replace ctitle(OLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h bandwidth, with controls;
rdrobust `x' dif if rel==1, bwselect(IK);
regress `x' after1986 di1* $contr1 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1, vce($se);
outreg2 using "output/t7_`x'", excel  append ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD-2SLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1, bwselect(IK);
ivregress 2sls `x' (schooling=after1986) di1* $contr1 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1, vce($se);
outreg2 using "output/t7_`x'", excel  append ctitle(Linear RD-2SLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**OLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
regress `x' schooling $contr1 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1& rural_pre12==1, vce($se);
outreg2 using "output/t7_`x'", excel  append ctitle(OLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
regress `x' after1986 di1* $contr2 [aw=womenweight] if abs(dif)<e(h_bw) & rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/t7_`x'", excel  append ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD-2SLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
ivregress 2sls `x' (schooling=after1986) di1* $contr2 [aw=womenweight] if abs(dif)<e(h_bw) &  rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/t7_`x'", excel  append ctitle(Linear RD-2SLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**reporting bandwidth;
rdrobust `x' dif if rel==1, bwselect(IK);
outreg2 using "output/t7_`x'", excel append ctitle(Bandwidth) addstat(BW Loc. Poly. (h), e(h_bw)) adec(0) nonotes nocons;

rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
outreg2 using "output/t7_`x'", excel append ctitle(Bandwidth) addstat(BW Loc. Poly. (h), e(h_bw)) adec(0) nonotes nocons;

**reporting mean;
rdrobust `x' dif if rel==1, bwselect(IK);
sum `x' [aw=womenweight] if abs(dif)<e(h_bw) & rel==1;
outreg2 using "output/t7_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;

rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
sum `x' [aw=womenweight] if abs(dif)<e(h_bw) & rural_pre12==1 & rel==1;
outreg2 using "output/t7_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;
};




********** APPENDIX TABLES;

********** TABLE A1: SUMMARY STATISTICS FOR 16-26 YEAR-OLD WOMEN;

foreach x in schooling jhighschool highschool primaryschool work_lastweek emp_nonagr service agriculture social_security z_income z_asset agree_notargue agree_spend agree_beat agree_childbeat agree_division agree_maleresponse agree_obligedsex z_attitudes rural_pre12 rural noturkish mother_violence{; 

regress `x' dif if abs(dif)<61;
sum `x' [aw=womenweight] if abs(dif)<61;
outreg2 using "output/ta1_`x'", excel replace ctitle(Mean) addstat(Mean, r(mean), Standard deviation, r(sd)) adec(2) nonotes nocons;
};

foreach x in schooling jhighschool highschool primaryschool work_lastweek emp_nonagr service agriculture social_security z_income z_asset agree_notargue agree_spend agree_beat agree_childbeat agree_division agree_maleresponse agree_obligedsex z_attitudes rural_pre12 rural noturkish mother_violence{;
regress `x' dif if abs(dif)<61 & rel==1;
sum `x' [aw=womenweight] if abs(dif)<61 & rel==1;
outreg2 using "output/ta1_`x'", excel append ctitle(Mean) addstat(Mean, r(mean), Standard deviation, r(sd)) adec(2) nonotes nocons;
};

foreach x in schooling jhighschool highschool primaryschool work_lastweek emp_nonagr service agriculture social_security z_income z_asset agree_notargue agree_spend agree_beat agree_childbeat agree_division agree_maleresponse agree_obligedsex z_attitudes rural_pre12 rural noturkish mother_violence{;
regress `x' dif if abs(dif)<61 & rel==0;
sum `x' [aw=womenweight] if abs(dif)<61 & rel==0;
outreg2 using "output/ta1_`x'", excel append ctitle(Mean) addstat(Mean, r(mean), Standard deviation, r(sd)) adec(2) nonotes nocons;
};

svyset HHID [pw=womenweight], strata(nuts2);

foreach x in schooling jhighschool highschool primaryschool work_lastweek emp_nonagr service agriculture social_security z_income z_asset agree_notargue agree_spend agree_beat agree_childbeat agree_division agree_maleresponse agree_obligedsex z_attitudes rural_pre12 rural noturkish mother_violence{;
svy: mean `x' if abs(dif)<61, over(rel);
lincom [`x']0 - [`x']1;
local tstat=r(estimate)/r(se);
local pval = tprob(r(df), abs(`tstat'));
outreg2 using "output/ta1_`x'", excel append ctitle(Difference) addstat(difference, r(estimate), standard, r(se), pval, `pval') adec(2) nonotes nocons;
};

********** TABLE A2: SUMMARY STATISTICS FOR 16-26 YEAR-OLD WOMEN WHO EVER HAD A RELATIONSHIP;

foreach x in slap push hit kick choked physical forced_sex forced_sex_fear humiliated_sex sexual insult humiliate threaten intervene_friends intervene_family intervene_location intervene_ignore intervene_otherman intervene_suspicious intervene_healthcare intervene_clothes emotional took_money refuse_money financial{; 

regress `x' dif if abs(dif)<61 & rel==1; 
sum `x' [aw=womenweight] if abs(dif)<61 & rel==1;
outreg2 using "output/ta2_`x'", excel replace ctitle(Mean) addstat(Mean, r(mean), Standard deviation, r(sd)) adec(2) nonotes nocons;
};

foreach x in slap push hit kick choked physical forced_sex forced_sex_fear humiliated_sex sexual insult humiliate threaten intervene_friends intervene_family intervene_location intervene_ignore intervene_otherman intervene_suspicious intervene_healthcare intervene_clothes emotional took_money refuse_money financial{; 

regress `x' dif if abs(dif)<61 & rel==1 & rural_pre12==1;
sum `x' [aw=womenweight] if abs(dif)<61 & rel==1 & rural_pre12==1;
outreg2 using "output/ta2_`x'", excel append ctitle(Mean) addstat(Mean, r(mean), Standard deviation, r(sd)) adec(2) nonotes nocons;
};

foreach x in slap push hit kick choked physical forced_sex forced_sex_fear humiliated_sex sexual insult humiliate threaten intervene_friends intervene_family intervene_location intervene_ignore intervene_otherman intervene_suspicious intervene_healthcare intervene_clothes emotional took_money refuse_money financial{; 

regress `x' dif if abs(dif)<61 & rel==1 & rural_pre12==0;
sum `x' [aw=womenweight] if abs(dif)<61 & rel==1 & rural_pre12==0;
outreg2 using "output/ta2_`x'", excel append ctitle(Mean) addstat(Mean, r(mean), Standard deviation, r(sd)) adec(2) nonotes nocons;
};

svyset HHID [pw=womenweight], strata(nuts2);

foreach x in slap push hit kick choked physical forced_sex forced_sex_fear humiliated_sex sexual insult humiliate threaten intervene_friends intervene_family intervene_location intervene_ignore intervene_otherman intervene_suspicious intervene_healthcare intervene_clothes emotional took_money refuse_money financial{; 

svy: mean `x' if abs(dif)<61 & rel==1, over(rural_pre12);
lincom [`x']0 - [`x']1;
local tstat=r(estimate)/r(se);
local pval = tprob(r(df), abs(`tstat'));
outreg2 using "output/ta2_`x'", excel append ctitle(Difference) addstat(difference, r(estimate), standard, r(se), pval, `pval') adec(2) nonotes nocons;
};

********** TABLE A3: RD TREATMENT EFFECTS ON COVARIATES AND RELATIONSHIP STATUS;

foreach x in region5_pre12_1 region5_pre12_2 region5_pre12_3 region5_pre12_4 region5_pre12_5 rural_pre12 noturkish mother_violence rural{;

**linear RD, h bandwidth, with controls;
rdrobust `x' dif if rel==1, bwselect(IK);
regress `x' after1986 di1* [aw=womenweight] if abs(dif)<e(h_bw) & rel==1, vce($se);
outreg2 using "output/ta3_`x'", excel  replace ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**reporting bandwidth;
rdrobust `x' dif if rel==1, bwselect(IK);
outreg2 using "output/ta3_`x'", excel append ctitle(Bandwidth) addstat(BW Loc. Poly. (h), e(h_bw)) adec(0) nonotes nocons;

**reporting mean;
rdrobust `x' dif if rel==1, bwselect(IK);
sum `x' [aw=womenweight] if abs(dif)<e(h_bw) & rel==1;
outreg2 using "output/ta3_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;
};

**joint significance;
sureg (region5_pre12_1 after1986 di1*) (region5_pre12_2 after1986 di1*) (region5_pre12_3 after1986 di1*) (region5_pre12_4 after1986 di1*) (rural_pre12 after1986 di1*) (noturkish after1986 di1*)  (mother_violence after1986 di1*)  (rural after1986 di1*)  [aw=womenweight] if abs(dif)<61& rel==1;
test after1986;

foreach x in rel married{;

**linear RD, h bandwidth, with controls;
rdrobust `x' dif, bwselect(IK);
regress `x' after1986 di1* [aw=womenweight] if abs(dif)<e(h_bw), vce($se);
outreg2 using "output/ta3_`x'", excel  replace ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**reporting bandwidth;
rdrobust `x' dif, bwselect(IK);
outreg2 using "output/ta3_`x'", excel append ctitle(Bandwidth) addstat(BW Loc. Poly. (h), e(h_bw)) adec(0) nonotes nocons;

**reporting mean;
rdrobust `x' dif, bwselect(IK);
sum `x' [aw=womenweight] if abs(dif)<e(h_bw);
outreg2 using "output/ta3_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;
};


********** TABLE A4: RD TREATMENT EFFECTS ON SCHOOLING BY CHILDHOOD REGION USING A STATIC BANDWIDTH;

foreach x in schooling jhighschool{;

**linear RD, h bandwidth, with controls;
regress `x' after1986 di1* $contr1 [aw=womenweight] if abs(dif)<61 & rel==1, vce($se);
outreg2 using "output/ta4_`x'", excel  replace ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**quadratic RD, h bandwidth, with controls;
regress `x' after1986 di1* di2* $contr1 [aw=womenweight] if abs(dif)<61 & rel==1, vce($se);
outreg2 using "output/ta4_`x'", excel  append ctitle(Quadratic RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h bandwidth, with controls;
regress `x' after1986 di1* $contr2 [aw=womenweight] if abs(dif)<61 & rural_pre12==1&rel==1, vce($se);
outreg2 using "output/ta4_`x'", excel  append ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**quadratic RD, h bandwidth, with controls;
regress `x' after1986 di1* di2* $contr2 [aw=womenweight] if abs(dif)<61 & rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/ta4_`x'", excel  append ctitle(Quadratic RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h bandwidth, with controls;
regress `x' after1986 di1* $contr2 [aw=womenweight] if abs(dif)<61 & rural_pre12==0&rel==1, vce($se);
outreg2 using "output/ta4_`x'", excel  append ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**quadratic RD, h bandwidth, with controls;
regress `x' after1986 di1* di2* $contr2 [aw=womenweight] if abs(dif)<61 & rural_pre12==0 & rel==1, vce($se);
outreg2 using "output/ta4_`x'", excel  append ctitle(Quadratic RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**reporting mean;
sum `x' [aw=womenweight] if abs(dif)<61 &rel==1;
outreg2 using "output/ta4_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;

sum `x' [aw=womenweight] if abs(dif)<61 & rural_pre12==1&rel==1;
outreg2 using "output/ta4_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;

sum `x' [aw=womenweight] if abs(dif)<61 & rural_pre12==0&rel==1;
outreg2 using "output/ta4_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;
};

*SUR test of difference between rural and urban regions;
foreach x in schooling jhighschool{;

**linear RD, h bandwidth, with controls, rural-urban;
regress `x' after1986 di1* $contr2 [aw=womenweight] if abs(dif)<61 & rural_pre12==1&rel==1;
est store r_`x';
regress `x' after1986 di1* $contr2 [aw=womenweight] if abs(dif)<61 & rural_pre12==0&rel==1;
est store u_`x';
suest r_`x' u_`x', vce($se);
test [r_`x'_mean]after1986 = [u_`x'_mean]after1986;
outreg2 using "output/ta4_`x'", excel append ctitle(Test) keep(after1986) addstat(chi-square test, r(p)) adec(3) nonotes nocons;
};

foreach x in schooling jhighschool{;

**quadratic RD, h bandwidth, with controls, rural-urban;
regress `x' after1986 di1* di2* $contr2 [aw=womenweight] if abs(dif)<61 & rural_pre12==1&rel==1;
est store r_`x';
regress `x' after1986 di1* di2* $contr2 [aw=womenweight] if abs(dif)<61 & rural_pre12==0&rel==1;
est store u_`x';
suest r_`x' u_`x', vce($se);
test [r_`x'_mean]after1986 = [u_`x'_mean]after1986;
outreg2 using "output/ta4_`x'", excel append ctitle(Test) keep(after1986) addstat(chi-square test, r(p)) adec(3) nonotes nocons;
};

********** TABLE A5: EDUCATION EFFECTS ON DOMESTIC VIOLENCE BY CHILDHOOD REGION USING A STATIC BANDWIDTH;

foreach x in z_physical z_sexual z_emotional z_financial{;

**OLS, h bandwidth, with controls;
regress `x' schooling $contr1 [aw=womenweight] if abs(dif)<61 & rel==1, vce($se);
outreg2 using "output/ta5_`x'", excel  replace ctitle(OLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h bandwidth, with controls;
regress `x' after1986 di1* $contr1 [aw=womenweight] if abs(dif)<61 & rel==1, vce($se);
outreg2 using "output/ta5_`x'", excel  append ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD-2SLS, h bandwidth, with controls;
ivregress 2sls `x' (schooling=after1986) di1* $contr1 [aw=womenweight] if abs(dif)<61 & rel==1, vce($se);
outreg2 using "output/ta5_`x'", excel  append ctitle(Linear RD-2SLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**OLS, h bandwidth, with controls;
regress `x' schooling $contr1 [aw=womenweight] if abs(dif)<61 & rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/ta5_`x'", excel  append ctitle(OLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h bandwidth, with controls;
regress `x' after1986 di1* $contr2 [aw=womenweight] if abs(dif)<61 & rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/ta5_`x'", excel  append ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD-2SLS, h bandwidth, with controls;
ivregress 2sls `x' (schooling=after1986) di1* $contr2 [aw=womenweight] if abs(dif)<61 &  rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/ta5_`x'", excel  append ctitle(Linear RD-2SLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**reporting mean;
sum `x' [aw=womenweight] if abs(dif)<61 & rel==1;
outreg2 using "output/ta5_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;

sum `x' [aw=womenweight] if abs(dif)<61 & rural_pre12==1 & rel==1;
outreg2 using "output/ta5_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;
};


********** TABLE A6: EDUCATION EFFECTS ON GENDER AND DOMESTIC VIOLENCE ATTITUDES BY CHILDHOOD REGION USING A STATIC BANDWIDTH;

foreach x in agree_notargue agree_spend agree_beat agree_division agree_childbeat agree_maleresponse agree_obligedsex z_attitudes{;

**OLS, h bandwidth, with controls;
regress `x' schooling $contr1 [aw=womenweight] if abs(dif)<61 & rel==1, vce($se);
outreg2 using "output/ta6_`x'", excel  replace ctitle(OLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h bandwidth, with controls;
regress `x' after1986 di1* $contr1 [aw=womenweight] if abs(dif)<61 & rel==1, vce($se);
outreg2 using "output/ta6_`x'", excel  append ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD-2SLS, h bandwidth, with controls;
ivregress 2sls `x' (schooling=after1986) di1* $contr1 [aw=womenweight] if abs(dif)<61 & rel==1, vce($se);
outreg2 using "output/ta6_`x'", excel  append ctitle(Linear RD-2SLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**OLS, h bandwidth, with controls;
regress `x' schooling $contr1 [aw=womenweight] if abs(dif)<61 & rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/ta6_`x'", excel  append ctitle(OLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h bandwidth, with controls;
regress `x' after1986 di1* $contr2 [aw=womenweight] if abs(dif)<61 & rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/ta6_`x'", excel  append ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD-2SLS, h bandwidth, with controls;
ivregress 2sls `x' (schooling=after1986) di1* $contr2 [aw=womenweight] if abs(dif)<61 &  rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/ta6_`x'", excel  append ctitle(Linear RD-2SLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**reporting mean;
sum `x' [aw=womenweight] if abs(dif)<61 & rel==1;
outreg2 using "output/ta6_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;

sum `x' [aw=womenweight] if abs(dif)<61 & rural_pre12==1 & rel==1;
outreg2 using "output/ta6_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;
};


********** TABLE A7: EDUCATION EFFECTS ON LABOR MARKET OUTCOMES BY CHILDHOOD REGION USING A STATIC BANDWIDTH;

foreach x in work_lastweek emp_nonagr service agriculture social_security z_income{;

**OLS, h bandwidth, with controls;
regress `x' schooling $contr1 [aw=womenweight] if abs(dif)<61 & rel==1, vce($se);
outreg2 using "output/ta7_`x'", excel  replace ctitle(OLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h bandwidth, with controls;
regress `x' after1986 di1* $contr1 [aw=womenweight] if abs(dif)<61 & rel==1, vce($se);
outreg2 using "output/ta7_`x'", excel  append ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD-2SLS, h bandwidth, with controls;
ivregress 2sls `x' (schooling=after1986) di1* $contr1 [aw=womenweight] if abs(dif)<61 & rel==1, vce($se);
outreg2 using "output/ta7_`x'", excel  append ctitle(Linear RD-2SLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**OLS, h bandwidth, with controls;
regress `x' schooling $contr1 [aw=womenweight] if abs(dif)<61 & rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/ta7_`x'", excel  append ctitle(OLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h bandwidth, with controls;
regress `x' after1986 di1* $contr2 [aw=womenweight] if abs(dif)<61 & rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/ta7_`x'", excel  append ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD-2SLS, h bandwidth, with controls;
ivregress 2sls `x' (schooling=after1986) di1* $contr2 [aw=womenweight] if abs(dif)<61 &  rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/ta7_`x'", excel  append ctitle(Linear RD-2SLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**reporting mean;
sum `x' [aw=womenweight] if abs(dif)<61 & rel==1;
outreg2 using "output/ta7_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;

sum `x' [aw=womenweight] if abs(dif)<61 & rural_pre12==1 & rel==1;
outreg2 using "output/ta7_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;
};


********** TABLE A8: EDUCATION EFFECTS ON PARTNER AND RELATIONSHIP CHARACTERISTICS BY CHILDHOOD REGION USING A STATIC BANDWIDTH;

foreach x in marriage_age marriage_decision working_men schooling_partner schooling_gap age_gap husband_age z_malereligious motherinlaw_violence partnerfaceddv divorced second_marriage z_asset{;

**OLS, h bandwidth, with controls;
regress `x' schooling $contr1 [aw=womenweight] if abs(dif)<61 & rel==1, vce($se);
outreg2 using "output/ta8_`x'", excel  replace ctitle(OLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h bandwidth, with controls;
regress `x' after1986 di1* $contr1 [aw=womenweight] if abs(dif)<61 & rel==1, vce($se);
outreg2 using "output/ta8_`x'", excel  append ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD-2SLS, h bandwidth, with controls;
ivregress 2sls `x' (schooling=after1986) di1* $contr1 [aw=womenweight] if abs(dif)<61 & rel==1, vce($se);
outreg2 using "output/ta8_`x'", excel  append ctitle(Linear RD-2SLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**OLS, h bandwidth, with controls;
regress `x' schooling $contr1 [aw=womenweight] if abs(dif)<61 & rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/ta8_`x'", excel  append ctitle(OLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h bandwidth, with controls;
regress `x' after1986 di1* $contr2 [aw=womenweight] if abs(dif)<61 & rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/ta8_`x'", excel  append ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD-2SLS, h bandwidth, with controls;
ivregress 2sls `x' (schooling=after1986) di1* $contr2 [aw=womenweight] if abs(dif)<61 &  rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/ta8_`x'", excel  append ctitle(Linear RD-2SLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**reporting mean;
sum `x' [aw=womenweight] if abs(dif)<61 & rel==1;
outreg2 using "output/ta8_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;

sum `x' [aw=womenweight] if abs(dif)<61 & rural_pre12==1 & rel==1;
outreg2 using "output/ta8_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;
};

********** TABLE A9, Columns 4-5: RD TREATMENT EFFECTS ON SCHOOLING AND DOMESTIC VIOLENCE IN RURAL CHILDHOOD REGIONS WITH DIFFERENT OPTIMAL BANDWIDTH SELECTION;
foreach x in schooling jhighschool{;

**linear RD, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
regress `x' after1986 di1* $contr2 [aw=womenweight] if abs(dif)<e(h_bw) & rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/ta9_45_`x'", excel  replace ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;
	
**reporting bandwidth;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
outreg2 using "output/ta9_45_`x'", excel append ctitle(Bandwidth) addstat(BW Loc. Poly. (h), e(h_bw)) adec(0) nonotes nocons;

**reporting mean;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
sum `x' [aw=womenweight] if abs(dif)<e(h_bw) & rural_pre12==1 & rel==1;
outreg2 using "output/ta9_45_`x'", excel append ctitle(Mean) addstat(Mean, r(mean)) adec(2) nonotes nocons;
};

foreach x in z_physical z_sexual z_emotional z_financial{;

**linear RD, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
regress `x' after1986 di1* $contr2 [aw=womenweight] if abs(dif)<e(h_bw) & rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/ta9_45_`x'", excel  replace ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD-2SLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
ivregress 2sls `x' (schooling=after1986) di1* $contr2 [aw=womenweight] if abs(dif)<e(h_bw) &  rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/ta9_45_`x'", excel  append ctitle(Linear RD-2SLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**reporting bandwidth;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
outreg2 using "output/ta9_45_`x'", excel append ctitle(Bandwidth) addstat(BW Loc. Poly. (h), e(h_bw)) adec(0) nonotes nocons;

**reporting mean;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
sum `x' [aw=womenweight] if abs(dif)<e(h_bw) & rural_pre12==1 & rel==1;
outreg2 using "output/ta9_45_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;
};


********** TABLE A10, Columns 4-5: RD TREATMENT EFFECTS ON MECHANISMS IN RURAL CHILDHOOD REGIONS WITH DIFFERENT OPTIMAL BANDWIDTH SELECTION;

foreach x in z_attitudes work_lastweek emp_nonagr z_income schooling_partner working_men marriage_age motherinlaw_violence{;

**linear RD, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
regress `x' after1986 di1* $contr2 [aw=womenweight] if abs(dif)<e(h_bw) & rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/ta10_45_`x'", excel  replace ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD-2SLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
ivregress 2sls `x' (schooling=after1986) di1* $contr2 [aw=womenweight] if abs(dif)<e(h_bw) &  rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/ta10_45_`x'", excel  append ctitle(Linear RD-2SLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**reporting bandwidth;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
outreg2 using "output/ta10_45_`x'", excel append ctitle(Bandwidth) addstat(BW Loc. Poly. (h), e(h_bw)) adec(0) nonotes nocons;

**reporting mean;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
sum `x' [aw=womenweight] if abs(dif)<e(h_bw) & rural_pre12==1 & rel==1;
outreg2 using "output/ta10_45_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;
};



********** TABLE A11: RD TREATMENT EFFECTS ON SCHOOLING USING 2014 HLFS DATA;

use "created/hlfs2014_for_graphs.dta", clear;

global contr1="month_* region26_* rural";
global se "cluster modate";	
global slvl "starlevels(* 0.10 ** 0.05 *** 0.01)";

foreach x in schooling jhighschool highschool primaryschool{;

**linear RD, h bandwidth, with controls;
rdrobust `x' dif if male==0, bwselect(IK);
regress `x' after1986 di1* $contr1 [aw=faktor] if abs(dif)<e(h_bw) & male==0, vce($se);
outreg2 using "output/ta11_`x'", excel  replace ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;
	
**quadratic RD, h bandwidth, with controls;
rdrobust `x' dif if male==0, bwselect(IK);
regress `x' after1986 di1* di2* $contr1 [aw=faktor] if abs(dif)<e(h_bw) &  male==0, vce($se);
outreg2 using "output/ta11_`x'", excel  append ctitle(Quadratic RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h/2 bandwidth, with controls;
rdrobust `x' dif if male==0, bwselect(IK);
regress `x' after1986 di1* $contr1 [aw=faktor] if abs(dif)<e(h_bw)/2 & male==0, vce($se);
outreg2 using "output/ta11_`x'", excel  append ctitle(Linear RD, h/2 bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

** linear RD, h*2 bandwidth, with controls;
rdrobust `x' dif if male==0, bwselect(IK);
regress `x' after1986 di1* $contr1 [aw=faktor] if abs(dif)<e(h_bw)*2 & male==0, vce($se);
outreg2 using "output/ta11_`x'", excel  append ctitle(Linear RD, 2h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**reporting bandwidth;
rdrobust `x' dif if male==0, bwselect(IK);
outreg2 using "output/ta11_`x'", excel append ctitle(Bandwidth) addstat(BW Loc. Poly. (h), e(h_bw)) adec(0) nonotes nocons;

**reporting mean;
rdrobust `x' dif if male==0, bwselect(IK);
sum `x' [aw=faktor] if abs(dif)<e(h_bw) &  male==0;
outreg2 using "output/ta11_`x'", excel append ctitle(Mean) addstat(Mean, r(mean)) adec(2) nonotes nocons;
};


********** TABLE A12: EDUCATION EFFECTS ON THE REASONS FOR WHY THE PARTNER PERPETRATED PHYSICAL VIOLENCE;
use "created/women_data_for_analysis.dta", clear;

global contr1="month_* noturkish region26_pre12_* rural_pre12";
global contr2="month_* noturkish region26_pre12_* rural";
global se "cluster modate";	
global slvl "starlevels(* 0.10 ** 0.05 *** 0.01)";

foreach x in partner_reason_children partner_reason_disobey partner_reason_economic partner_reason_fidelity partner_reason_jealous partner_reason_pfamily partner_reason_sex partner_reason_wfamily partner_reason_wjealous{;

**OLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1, bwselect(IK);
regress `x' schooling $contr1 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1, vce($se);
outreg2 using "output/ta12_`x'", excel  replace ctitle(OLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h bandwidth, with controls;
rdrobust `x' dif if rel==1, bwselect(IK);
regress `x' after1986 di1* $contr1 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1, vce($se);
outreg2 using "output/ta12_`x'", excel  append ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD-2SLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1, bwselect(IK);
ivregress 2sls `x' (schooling=after1986) di1* $contr1 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1, vce($se);
outreg2 using "output/ta12_`x'", excel  append ctitle(Linear RD-2SLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**OLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
regress `x' schooling $contr1 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1& rural_pre12==1, vce($se);
outreg2 using "output/ta12_`x'", excel  append ctitle(OLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
regress `x' after1986 di1* $contr2 [aw=womenweight] if abs(dif)<e(h_bw) & rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/ta12_`x'", excel  append ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD-2SLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
ivregress 2sls `x' (schooling=after1986) di1* $contr2 [aw=womenweight] if abs(dif)<e(h_bw) &  rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/ta12_`x'", excel  append ctitle(Linear RD-2SLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**reporting bandwidth;
rdrobust `x' dif if rel==1, bwselect(IK);
outreg2 using "output/ta12_`x'", excel append ctitle(Bandwidth) addstat(BW Loc. Poly. (h), e(h_bw)) adec(0) nonotes nocons;

rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
outreg2 using "output/ta12_`x'", excel append ctitle(Bandwidth) addstat(BW Loc. Poly. (h), e(h_bw)) adec(0) nonotes nocons;

**reporting mean;
rdrobust `x' dif if rel==1, bwselect(IK);
sum `x' [aw=womenweight] if abs(dif)<e(h_bw) & rel==1;
outreg2 using "output/ta12_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;

rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
sum `x' [aw=womenweight] if abs(dif)<e(h_bw) & rural_pre12==1 & rel==1;
outreg2 using "output/ta12_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;
};

********** TABLE A13: EDUCATION EFFECTS ON FERTILITY-RELATED OUTCOMES;

foreach x in ever_used_contraceptive ever_given_birth num_children partner_disapproves_contra{;

**OLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1, bwselect(IK);
regress `x' schooling $contr1 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1, vce($se);
outreg2 using "output/ta13_`x'", excel  replace ctitle(OLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h bandwidth, with controls;
rdrobust `x' dif if rel==1, bwselect(IK);
regress `x' after1986 di1* $contr1 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1, vce($se);
outreg2 using "output/ta13_`x'", excel  append ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD-2SLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1, bwselect(IK);
ivregress 2sls `x' (schooling=after1986) di1* $contr1 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1, vce($se);
outreg2 using "output/ta13_`x'", excel  append ctitle(Linear RD-2SLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**OLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
regress `x' schooling $contr1 [aw=womenweight] if abs(dif)<e(h_bw) & rel==1& rural_pre12==1, vce($se);
outreg2 using "output/ta13_`x'", excel  append ctitle(OLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
regress `x' after1986 di1* $contr2 [aw=womenweight] if abs(dif)<e(h_bw) & rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/ta13_`x'", excel  append ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD-2SLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
ivregress 2sls `x' (schooling=after1986) di1* $contr2 [aw=womenweight] if abs(dif)<e(h_bw) &  rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/ta13_`x'", excel  append ctitle(Linear RD-2SLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**reporting bandwidth;
rdrobust `x' dif if rel==1, bwselect(IK);
outreg2 using "output/ta13_`x'", excel append ctitle(Bandwidth) addstat(BW Loc. Poly. (h), e(h_bw)) adec(0) nonotes nocons;

rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
outreg2 using "output/ta13_`x'", excel append ctitle(Bandwidth) addstat(BW Loc. Poly. (h), e(h_bw)) adec(0) nonotes nocons;

**reporting mean;
rdrobust `x' dif if rel==1, bwselect(IK);
sum `x' [aw=womenweight] if abs(dif)<e(h_bw) & rel==1;
outreg2 using "output/ta13_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;

rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(IK);
sum `x' [aw=womenweight] if abs(dif)<e(h_bw) & rural_pre12==1 & rel==1;
outreg2 using "output/ta13_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;
};


/*
********** TABLE A9, Columns 1-3: RD TREATMENT EFFECTS ON SCHOOLING AND DOMESTIC VIOLENCE IN RURAL CHILDHOOD REGIONS WITH DIFFERENT OPTIMAL BANDWIDTH SELECTION;
**Please install the following rdrobust command prior to running this section: net install rdrobust, from(http://www-personal.umich.edu/~cattaneo/software/rdrobust/stata) replace;
foreach x in schooling jhighschool{;

**linear RD, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(mserd) scaleregul(0);
regress `x' after1986 di1* $contr2 [aw=womenweight] if dif>-e(h_l) & dif<e(h_r) & rel==1& rural_pre12==1, vce($se);
outreg2 using "output/ta9_13_`x'", excel  replace ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;
	
**reporting bandwidth;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(mserd) scaleregul(0);
outreg2 using "output/ta9_13_`x'", excel append ctitle(Bandwidth) addstat(BW Loc. Poly. (h), e(h_l), BW Loc. Poly. (h), e(h_r)) adec(0) nonotes nocons;

**reporting mean;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(mserd) scaleregul(0);
sum `x' [aw=womenweight] if dif>-e(h_l) & dif<e(h_r);
outreg2 using "output/ta9_13_`x'", excel append ctitle(Mean) addstat(Mean, r(mean)) adec(2) nonotes nocons;
};

foreach x in z_physical z_sexual z_emotional z_financial{;

**OLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(mserd) scaleregul(0);
regress `x' schooling $contr1 [aw=womenweight] if dif>-e(h_l) & dif<e(h_r) & rel==1& rural_pre12==1, vce($se);
outreg2 using "output/ta9_13_`x'", excel  append ctitle(OLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(mserd)scaleregul(0);
regress `x' after1986 di1* $contr2 [aw=womenweight] if dif>-e(h_l) & dif<e(h_r) & rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/ta9_13_`x'", excel  append ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD-2SLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(mserd) scaleregul(0);
ivregress 2sls `x' (schooling=after1986) di1* $contr2 [aw=womenweight] if dif>-e(h_l) & dif<e(h_r) &  rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/ta9_13_`x'", excel  append ctitle(Linear RD-2SLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**reporting bandwidth;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(mserd) scaleregul(0);
outreg2 using "output/ta9_13_`x'", excel append ctitle(Bandwidth) addstat(BW Loc. Poly. (h), e(h_l), BW Loc. Poly. (h), e(h_r)) adec(0) nonotes nocons;

**reporting mean;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(mserd) scaleregul(0) ;
sum `x' [aw=womenweight] if dif>-e(h_l) & dif<e(h_r) & rural_pre12==1 & rel==1;
outreg2 using "output/ta9_13_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;
};


********** TABLE A10, Columns 1-3: RD TREATMENT EFFECTS ON MECHANISMS IN RURAL CHILDHOOD REGIONS WITH DIFFERENT OPTIMAL BANDWIDTH SELECTION;
**Please install the following rdrobust command prior to running this section: net install rdrobust, from(http://www-personal.umich.edu/~cattaneo/software/rdrobust/stata) replace;

foreach x in z_attitudes work_lastweek emp_nonagr z_income schooling_partner working_men marriage_age motherinlaw_violence{;

**OLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(mserd) scaleregul(0);
regress `x' schooling $contr1 [aw=womenweight] if dif>-e(h_l) & dif<e(h_r) & rel==1& rural_pre12==1, vce($se);
outreg2 using "output/ta10_13_`x'", excel  replace ctitle(OLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(mserd)scaleregul(0);
regress `x' after1986 di1* $contr2 [aw=womenweight] if dif>-e(h_l) & dif<e(h_r) & rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/ta10_13_`x'", excel  append ctitle(Linear RD, h bandwidth) keep(after1986) se bdec(3) sdec(3) nor2 nonotes nocons;

**linear RD-2SLS, h bandwidth, with controls;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(mserd) scaleregul(0);
ivregress 2sls `x' (schooling=after1986) di1* $contr2 [aw=womenweight] if dif>-e(h_l) & dif<e(h_r) &  rural_pre12==1 & rel==1, vce($se);
outreg2 using "output/ta10_13_`x'", excel  append ctitle(Linear RD-2SLS, h bandwidth) keep(schooling) se bdec(3) sdec(3) nor2 nonotes nocons;

**reporting bandwidth;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(mserd) scaleregul(0);
outreg2 using "output/ta10_13_`x'", excel append ctitle(Bandwidth) addstat(BW Loc. Poly. (h), e(h_l), BW Loc. Poly. (h), e(h_r)) adec(0) nonotes nocons;

**reporting mean;
rdrobust `x' dif if rel==1& rural_pre12==1, bwselect(mserd) scaleregul(0) ;
sum `x' [aw=womenweight] if dif>-e(h_l) & dif<e(h_r) & rural_pre12==1 & rel==1;
outreg2 using "output/ta10_13_`x'", excel append ctitle(Mean) keep(schooling) addstat(Mean, r(mean)) adec(2) nonotes nocons;
};
*/

