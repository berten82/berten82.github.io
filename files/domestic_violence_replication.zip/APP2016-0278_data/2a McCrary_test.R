#Last modified: 01/24/2017

rm(list=ls())
setwd("XXX/Domestic Violence")
install.packages("rdd")
library(rdd)
library(foreign)

mydata <- read.dta("originals/women_data_for_analysis.dta")
sample100 <- mydata[which(mydata$dif>=-100 & mydata$dif<=80),]

par(mfrow=c(1,1), cex=1)

den<-DCdensity(sample100$dif, bin=1, bw=61, ext.out=TRUE)

##Adding titles and vertical line at cutoff point (dif=0)
title(xlab='Born After January 1987 (In Months)', ylab='Density')
abline(v=0, lwd=2, lty=2)
